#!/bin/bash

java -cp ".:../java-json.jar" JSONObjectBuggyDuplicates test.json
