#!/bin/bash

java -cp ".:../java-json.jar" JSONObjectCatchDuplicates test.json
