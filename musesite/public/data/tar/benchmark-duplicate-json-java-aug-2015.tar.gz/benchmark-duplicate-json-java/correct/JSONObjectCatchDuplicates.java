 
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import org.json.JSONException;
import org.json.JSONObject;


public class JSONObjectCatchDuplicates extends JSONObject {
	

    public JSONObjectCatchDuplicates(String json) throws JSONException {
        super(json);             
    }

    public JSONObjectCatchDuplicates putOnce(String key, Object value) throws JSONException {
            Object storedValue;
            if (key != null && value != null) {
                if ((storedValue = this.opt(key)) != null ) {
//                    if(!storedValue.equals(value)){
                    	System.out.println("duplicate key found: " + key);
                    	writeDuplicateKey(key);

                        return this;
                }
                this.put(key, value);
            }
            return this;
        }
    
    private void writeDuplicateKey(String key){
    	try {
			FileWriter fw = new FileWriter("duplicateKeys.txt", true);

			fw.write(key + System.getProperty("line.separator"));
			fw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//appends the string to the file
    }
    
    public static void main(String[] args) {
    	
    	File inFile = null;
    	if (args.length > 0) {
    	   inFile = new File(args[0]);
    	} else {
    	   System.err.println("Invalid arguments count:" + args.length);
    	   System.out.println("Please provided an input json file.");
    	   System.exit(1);
    	}
    	try {
			FileWriter fw = new FileWriter("duplicateKeys.txt");
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
    	
    	String json;
		try {
			json = readFile(inFile);
			JSONObjectCatchDuplicates json_obj = new JSONObjectCatchDuplicates(json);

             System.out.println("==JSON object==");
             System.out.println(json_obj.toString());
         } catch (JSONException e) {
             throw new RuntimeException(e);
		 } catch (IOException e1) {
			System.err.println("Error reading file: " + inFile);
		}
		
    }  
    
    private static String readFile(File file) throws IOException {

        StringBuilder fileContents = new StringBuilder((int)file.length());
        Scanner scanner = new Scanner(file);
        String lineSeparator = System.getProperty("line.separator");

        try {
            while(scanner.hasNextLine()) {        
                fileContents.append(scanner.nextLine() + lineSeparator);
            }
            return fileContents.toString();
        } finally {
            scanner.close();
        }
    }
}
