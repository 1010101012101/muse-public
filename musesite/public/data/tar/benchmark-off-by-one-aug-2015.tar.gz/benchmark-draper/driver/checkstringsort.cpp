/***************************************
 *
 *  A simple filter to check whether the data on stdin is sorted in
 * increasing order.
 *
 ******/


#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include "CheckSort.h"
#include "stringcmp.h"

int main()
{
  char buffer[512];
  std::vector<stringcmp> strings;

  while (fgets(buffer, 511, stdin))
    {
      strings.push_back(buffer);
    }

  CheckSort<stringcmp, true> checker;
  if (checker(strings))
    {
      printf("passed\n");
      return (0);
    }
  else
    {
      printf("failed\n");
      return (1);
    }
}
