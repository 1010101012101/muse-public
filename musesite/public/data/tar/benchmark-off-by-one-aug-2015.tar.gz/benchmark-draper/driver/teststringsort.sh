#!/bin/bash
#
# Usage: testintsort <num tests> <seed> <executable>
#
#  Test a program that sorts strings from stdin and prints them to
# stdout in increasing order.
#

for i in $(seq 0 $1);
do
    randomstring $(($2 + $i)) > string_tests
    cat string_tests | $3 | checkstringsort
    if [[ $? != 0 ]]; then exit 1; fi
done
