/******************************************************
 *
 *  Generate a list of random ints. The reason for not just using
 * /dev/urandom for this is that using code makes it easier to
 * give the length of the list a geometric distribution, which ought
 * to help us hit corner cases more easily. While we're at it we can
 * also give the numbers themselves a geometric distribution for the
 * same reason. We don't need pseudorandom numbers for reproducibility
 * since we can just save the results to a file, but on the other hand
 * it's nice to make the test drivers for this challenge problem behave
 * similarly to the test drivers for the others.
 *
 *
 ****/


#include <boost/random/variate_generator.hpp>
#include <boost/random.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <boost/random/geometric_distribution.hpp>

int main(int argc, char **argv)
{
  typedef boost::random::uniform_int_distribution <> uniform;
  typedef boost::random::geometric_distribution <> geometric;

  boost::mt19937 m_rng(atoi(argv[1]));

  boost::variate_generator <boost::random::mt19937 &, geometric>
    lengen(m_rng, geometric(0.01));

  unsigned numElements = lengen();
  for (unsigned i = 0; i < numElements; i++)
    std::cout << lengen() << "\n";
}

  
