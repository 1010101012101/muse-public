#include <assert.h>
#include <vector>
#include <iostream>

#include "ReferenceFacade.h"

class JSONelement: public Utility::ReferenceFacade
{
 public:

  JSONelement()
  {}

  JSONelement(const JSONelement & rhs):
    ReferenceFacade(rhs)
  {}

  void printMe(std::ostream & str, unsigned tabs) const
  {
    if (exists())
      implementation_const()->printMe(str, tabs);
    else
      str << "[]";
  }
  
  std::string stringify() const
  {
    if (exists())
      return implementation_const()->stringify();
    else
      return "";
  }

    unsigned numElements() const
    {
	if (exists())
	    return implementation_const()->numElements();
	else
	    return 0;
    }

    JSONelement getElement(unsigned i) const
    {
	if (exists())
	    return implementation_const()->getElement(i);
	else
	    return JSONelement();
    }

    bool isList() const
    {
      if (exists())
	return implementation_const()->isList();
      else
	  return false;
    }
    
    bool isObject() const
    {
      if (exists())
	return implementation_const()->isObject();
      else
	  return false;
    }

 protected:

  class Implementation: public Utility::RefImpl
  {
  public:

      virtual void printMe(std::ostream & str, unsigned tabs) const
      {
	  assert(0);
      }
      
      void printTabs(std::ostream & str, unsigned tabs) const
      {
	  for (unsigned i = 0; i < tabs; i++)
	      str << "  ";
      }
      
      
      virtual std::string stringify() const
      {
	  printMe(std::cerr, 0);
	  assert(0);
      }

      virtual bool isList() const
      {
	return false;
      }

      virtual bool isObject() const
      {
	return false;
      }

      virtual unsigned numElements() const = 0;
      virtual JSONelement getElement(unsigned) const = 0;
   };

  
  JSONelement(Implementation *impl):
    ReferenceFacade(impl)
  {}

  const Implementation * implementation_const() const
  {
    return dynamic_cast<const Implementation *>
      (Utility::ReferenceFacade::implementation_const());
  }
  
};


class JSONarray: public JSONelement
{
  
public:
  
  JSONarray():
   JSONelement(new Implementation)
  {}

  JSONarray(JSONelement elt):
    JSONelement(new Implementation(elt))
  {}

  void addElement(const JSONelement elt)
  {
    if (!elt.exists())
      return;
    
    if (!exists())
      {
	JSONarray newArray(new Implementation);
	(*this) = newArray;
      }

    implementation()->addElement(elt);
  }

protected:

  class Implementation: public JSONelement::Implementation
  {
    
  public:

    Implementation()
    {}

    Implementation(const JSONelement elt)
    {
      if (elt.exists())
	m_elements.push_back(elt);
    }

    void addElement(const JSONelement elt)
    {
      if (elt.exists())
	m_elements.push_back(elt);
    }

      virtual unsigned numElements() const
      {
	  return m_elements.size();
      }

      virtual JSONelement getElement(unsigned i) const
      {
	  if (i < m_elements.size())
	      return m_elements[i];
	  else
	      return JSONelement();
      }

    virtual void printMe(std::ostream & str, unsigned tabs) const
    {
	str << "\n";
	printTabs(str, tabs);
	str << "[\n";

      unsigned first = true;
      for (unsigned i = 0; i < m_elements.size(); i++)
      {
	if (first)
	  first = false;
	else
	  str << ",\n";
	printTabs(str, tabs+1);
	if (m_elements[i].exists())
	  m_elements[i].printMe(str, tabs+1);
	else
	  str << "[]";
      }

      str << "\n";
      printTabs(str, tabs);
      str << "]";
    }

      
  private:

    std::vector<JSONelement> m_elements;
  };

  JSONarray(Implementation * impl):
    JSONelement(impl)
  {}
  
  Implementation * implementation()
  {
    return dynamic_cast<Implementation *>
      (Utility::ReferenceFacade::implementation());
  }
};

class JSONnamedElement: public JSONelement
{
public:

  JSONnamedElement()
  {}

  JSONnamedElement(const std::string & label,
		   const JSONelement & elt):
    JSONelement(new Implementation(label, elt))
  {}

  
protected:

  class Implementation: public JSONelement::Implementation
  {
  public:

      Implementation(const std::string & key,
		     const JSONelement & elt):
	  m_key(key),
	  m_element(elt)
      {}
      
      virtual unsigned numElements() const
      {
	  return 1;
      }

      virtual JSONelement getElement(unsigned i) const
      {
	  if (i == 0)
	      return m_element;
	  else
	      return JSONelement();
      }

    virtual void printMe(std::ostream & str, unsigned tabs) const
    {
      printTabs(str, tabs);
      str << "\"" << m_key << "\": ";
      if (m_element.exists())
	m_element.printMe(str, tabs+1);
      else
	str << "[]";
    }

  private:

    const std::string m_key;
    const JSONelement m_element;
  };
};
  
class JSONstring: public JSONelement
{
  
public:

  JSONstring()
  {}

  JSONstring(const std::string & str):
    JSONelement(new Implementation(str))
  {}

protected:

  class Implementation: public JSONelement::Implementation
  {
  public:

    Implementation(const std::string & str):
      m_string(str)
    {}

      virtual unsigned numElements() const
      {
	  return 0;
      }

      virtual JSONelement getElement(unsigned i) const
      {
	  return JSONelement();
      }

    virtual void printMe(std::ostream & str, unsigned tabs) const
    {
      str << "\"" << m_string << "\"";
    }

    virtual std::string stringify() const
    {
      return m_string;
   } 

  private:

    const std::string m_string;
  };
};

class JSONlist: public JSONelement
{
  
public:

    JSONlist()
    {}

  void addElement(const JSONelement elt)
  {
    if (!elt.exists())
      return;
    
    if (!exists())
      {
	  JSONlist newList(new Implementation);
	  (*this) = newList;
      }

    implementation()->addElement(elt);
  }

  unsigned numElements() const
  {
    if (!exists())
      return 0;
    else
      return implementation_const()->numElements();
  }

  JSONelement getElement(unsigned i)
  {
    if (!exists())
      return JSONelement();
    else
      return implementation_const()->getElement(i);
  }

  virtual bool isList() const
  {
    return true;
  }
  
protected:

  class Implementation: public JSONelement::Implementation
  {

  public:

    Implementation()
    {}

    void addElement(const JSONelement elt)
    {
      if (elt.exists())
	m_elements.push_back(elt);
    }

    virtual unsigned numElements() const
    {
      return m_elements.size();
    }

    virtual JSONelement getElement(unsigned i) const
    {
      if (i < m_elements.size())
	return m_elements[i];
      else
	return JSONelement();
    }
    
    virtual void printMe(std::ostream & str, unsigned tabs) const
    {
      unsigned first = true;
      for (unsigned i = 0; i < m_elements.size(); i++)
      {
	if (first)
	  first = false;
	else
	  str << ",\n";
	
	m_elements[i].printMe(str, tabs);
      }
    }

    virtual std::string stringify() const
    {
      std::string result;
      unsigned first = true;
      for (unsigned i = 0; i < m_elements.size(); i++)
      {
	if (first)
	  first = false;
	else
	  result = result + ".";
	
	result = result + m_elements[i].stringify();
      }

      return result;
    }
    
  private:

    std::vector<JSONelement> m_elements;
  };

  JSONlist(Implementation * impl):
    JSONelement(impl)
  {}

  Implementation * implementation()
  {
    return dynamic_cast<Implementation *>
      (Utility::ReferenceFacade::implementation());
  }

  const Implementation * implementation_const() const
  {
    return dynamic_cast<const Implementation *>
      (Utility::ReferenceFacade::implementation_const());
  }
};
    
class JSONobject: public JSONelement
{
    
public:

    JSONobject()
    {}
    
    JSONobject(const JSONelement & elt):
	JSONelement(new Implementation(elt))
    {}
    
protected:
    
    class Implementation: public JSONelement::Implementation
    {
	
    public:
	
	Implementation(const JSONelement & elt):
	    m_element(elt)
	{}

	virtual unsigned numElements() const
	{
	  return 1;
	}

	virtual JSONelement getElement(unsigned i) const
	{
	    if (i == 0)
		return m_element;
	    else
		return JSONelement();
	}

	virtual std::string stringify() const
	{
	    return m_element.stringify();
	}
	
	virtual void printMe(std::ostream & str, unsigned tabs) const
	{
	    str << "\n";
	    printTabs(str, tabs);
	    str << "{\n";
	    if (m_element.exists())
		m_element.printMe(str, tabs+1);
	    str << "\n";
	    printTabs(str, tabs);
	    str << "}";
	}

	virtual bool isObject() const
	{
	  return true;
	}

    private:
	
	const JSONelement m_element;
    };
};

class JSONlogical: public JSONelement
 {
   
 public:
   
   JSONlogical()
   {}
   
   JSONlogical(bool value):
     JSONelement(new Implementation(value))
   {}

 protected:

   class Implementation: public JSONelement::Implementation
   {
     
   public:

     Implementation(bool value):
       m_value(value)
     {}

     virtual void printMe(std::ostream & str, unsigned) const
     {
       if (m_value)
	 str << "true";
       else
	 str << "false";
     }

     unsigned numElements() const
     {
       return 0;
     }

     JSONelement getElement(unsigned) const
     {
       return JSONelement();
     }
     
   private:

     const bool m_value;
   };

 };

 class JSONint: public JSONelement
 {
   
 public:
   
   JSONint()
   {}
   
   JSONint(int value):
     JSONelement(new Implementation(value))
   {}

 protected:

   class Implementation: public JSONelement::Implementation
   {
     
   public:

     Implementation(int value):
       m_value(value)
     {}

     virtual void printMe(std::ostream & str, unsigned) const
     {
       str << m_value;
     }

     unsigned numElements() const
     {
       return 0;
     }

     JSONelement getElement(unsigned) const
     {
       return JSONelement();
     }
     
   private:

     const int m_value;
   };
 };
 
 class JSONfloat: public JSONelement
 {
   
 public:
   
   JSONfloat()
   {}
   
   JSONfloat(int value):
     JSONelement(new Implementation(value))
   {}

 protected:

   class Implementation: public JSONelement::Implementation
   {
     
   public:

     Implementation(float value):
       m_value(value)
     {}

     virtual void printMe(std::ostream & str, unsigned) const
     {
       str << m_value;
     }

     unsigned numElements() const
     {
       return 0;
     }

     JSONelement getElement(unsigned) const
     {
       return JSONelement();
     }
     
   private:

     const float m_value;
   };
 };
