#pragma once


/************************************
 *
 *   Thia is a pair of base classes used to implement managed
 * pointers in such a way that the raw pointer is statically protected
 * (so the people don't accidently start passing raw pointers around).
 * The idea is that the class that the mananged pointer points to is
 * statically enclosed in the managing class.
 *   The managed class is derived from RefImpl, which provides the
 * reference count and methods for accessing it. The managing class
 * is derived from ReferenceFacade, which accepts a managed pointer
 * in its constructor, tracks its reference count and deletes it when
 * there are no more references to it. It also acts as a facade because
 * calls to the managed object go through the manager. Needless to
 * say, the managing subclass shouldn't expose the managed pointer.
 *   The managed class is meant to be only the size of a pointer so
 * that it can be passed around with no more overhead than a pointer
 * would use. The only data member is a pointer to a managed object,
 * so subclasses of ReferenceFacade should have no data members or
 * virtual methods. Polymorphism can be implemented using only virtual 
 * functions in the managed classs since a ReferenceFacade managing
 * pointers to class X can actually contain a pointer to an instance of
 * a subclass of X.
 *   The constructors of a ReferenceFacade subclass should ensure that
 * it can only contain managed pointers from the correct class. The
 * pointer itself doesn't provide static type safety because it's stored as
 * a RefImpl *. For the same reason, the pointer has to be cast down
 * before a ReferenceFacade object can relat messages to it. But in the
 * code for a given ReferenceFacade subclass, the managed pointer is always
 * cast down to the same thing, namely the RefImpl subclass managed by
 * that ReferenceFacade subclass. I standardly have two methods, named
 * implementation() and implementation_const(), in each ReferenceFacade
 * subclass for this purpose.
 *   Class inheritance is implemented by giving each ReferenceFacade object
 * a protected constructor that accepts a pointer to the managed subclass.
 * When a ReferenceFacade object is instantiated it allocates a new object
 * of the managed type, passing its own constructor arguments to the 
 * constructor of the newly allocated object. The ReferenceFacade object
 * passses the resulting pointer to its superclass using the protected 
 * constructor of its superclass, which passes it to its own superclass,
 * and so on until it reaches the ReferenceFacade class. This stores the
 * pointer and sets its reference count.
 *   It's tempting to implement downcasting using constructors in
 * ReferenceFacade subclasses. Technically any ReferenceFacade object
 * can be cast to any other ReferenceFacade object if the second 
 * object can extract its implementation pointer and pass it up
 * its own inheritance chain. However this completely breaks static
 * type safety (even when it's just used for downcasting) and if there's
 * an undetected type problem it'll only show up at runtime when the
 * dynamic cast in an implementation() method fails. Therefore I'm
 * using specially named methods for downcasting, so that if there
 * is a problem of this kind it'll be easier to track where it came
 * from.
 *   In general, a ReferenceFacade object acts like a reference in
 * Java. If A and B are ReferenceFacade subclasses then A = B is really 
 * a pointer assignment and A and B end up aliased. When we need to copy 
 * something out we need an explicit clone method. (C++ is smart enough
 * to type-check this assignment even though the ReferenceFacade base
 * class defines '=' between two ReferenceFacade objects; that is, if
 * A and B are unrelated ReferenceFacade subclasses then A=B doesn't
 * compile. 
 *  If the managed pointer is a null pointer then the ReferenceFacade is a 
 * null reference, and the ReferenceFacade method exists() returns false when 
 * the managed pointer is null. Normally I use the default constructor to
 * create null references, and these are convenient to use as return values
 * when the thing that was supposed to be returned doesn't exist for some
 * reason
 *  A RefImpl subclass can't contain an instance of the ReferenceFacade
 * subclass that manages it. This is because the declaration of the subclass
 * is statically inside the definition of the managing class, so the managing
 * class is incomplete when the definition occurs. That means that 
 * ReferenceFacades can't directly implement things like linked lists or
 * trees; if we used them that way we'd be in danger of creating a circular
 * chain of reference that would never be cleaned up. It's better to use
 * a lookup table; for example a CFG contains a table that allows basic blocks
 * to be looked up by address, and basic blocks can refer to other basic
 * blocks using those addresses. (This setup also makes it easier to 
 * swap basic blocks in and out). A RefImpl subclass can still have a container
 * class that will contain instances of its own managing class. This should
 * be avoided even though it compiles because of the circular reference issue.
 *  In various places I pass ReferenceFacade objects by reference, but I 
 * realized that this might actually be slower than passing them by value.
 * In the first case we just push the whole (4-byte) object on the stack,
 * but in the second case the compiler might decide to actually find the
 * address of the object before pushing it onto the stack, requiring
 * an extra instruction (that's nitpicking though).
 *   The big shortcoming of ReferenceFacades is that I don't have a way
 * to statically const the managed object. If A is a consted ReferenceFacade
 * object, I can do essentially anything I want to it by assigning it to
 * a non-const ReferenceFacade and modifying that.
 *
 */


#include <stddef.h>
#include <assert.h>

namespace Utility
{
class RefImpl
{
public:

    RefImpl():
        m_referenceCount(0)
        {}

    virtual ~RefImpl()
    {}

    inline unsigned incrementRefCount()   
    { 
        m_referenceCount++;
	assert(m_referenceCount);
        return m_referenceCount;
    }

    inline unsigned decrementRefCount()   
    { 
        assert(m_referenceCount);
        m_referenceCount--;
        return m_referenceCount;
    }

    inline unsigned testReferenceCount() const
    {
        return m_referenceCount;
    }

private:

    unsigned m_referenceCount;

};

class ReferenceFacade
{

public:

    ReferenceFacade():
        m_implementation(0)
        {}

    ReferenceFacade(RefImpl *implementation)
    {
        rawAdopt(implementation);
    }

    ReferenceFacade(const ReferenceFacade &rhs)
    {
        rawAdopt(const_cast<RefImpl *>(rhs.implementation_const()));
    }

    ~ReferenceFacade()
    {
        release();
    }

    inline const ReferenceFacade & operator = (const ReferenceFacade &rhs)
    {
        adopt(const_cast<RefImpl *>(rhs.implementation_const()));
        return *this;
    }

    inline bool exists() const
    {
        return (m_implementation != 0);
    }

    void unExist()
    {
        release();
    }

    size_t uniqueIndex() const
    {
      return (size_t)m_implementation;
    }

protected:

    inline RefImpl *implementation()
    {
        return m_implementation;
    }

    inline const RefImpl *implementation_const() const
    {
        return m_implementation;
    }

private:

    inline void rawAdopt(RefImpl *implementation)
    {
        m_implementation = implementation;
        if (m_implementation)
            m_implementation->incrementRefCount();
    }

    inline void adopt(RefImpl *implementation)
    {
        if (implementation == m_implementation)
            return;

        release();

        rawAdopt(implementation);
    }

    inline void release()
    {
        if (m_implementation && !m_implementation->decrementRefCount())
        {
            delete m_implementation;
        }
        m_implementation = 0;

    }

    RefImpl *m_implementation;
};

    template<class Wrapper>
    typename Wrapper::Implementation * implementation()
    {
	return dynamic_cast<typename Wrapper::Implementation *>
	    ((ReferenceFacade)Wrapper::implementation());
    }

    template<class Wrapper>
    const typename Wrapper::Implementation * implementation_const()
    {
	return dynamic_cast<const typename Wrapper::Implementation *>
	    ((ReferenceFacade)Wrapper::implementation_const());
    }


    template<class Self>
 class ReferenceClass: public ReferenceFacade
 {
     
 public:
     
     ReferenceClass()
     {}
     
 protected:
     
     class Implementation;
     
     Implementation * implementation()
     {
	 return dynamic_cast<Implementation *>
	     (ReferenceFacade::implementation());
     }

     const Implementation * implementation_const() const
     {
	 return dynamic_cast<const Implementation *>
	     (ReferenceFacade::implementation_const());
     }

     ReferenceClass(Implementation *impl):
	 ReferenceFacade(impl)
     {}
 };
};
