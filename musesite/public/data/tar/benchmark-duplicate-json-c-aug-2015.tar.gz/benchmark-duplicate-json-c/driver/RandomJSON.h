#include <float.h>
#include <vector>
#include "JSONelements.h"

#include <boost/random/variate_generator.hpp>
#include <boost/random.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <boost/random/uniform_real_distribution.hpp>
#include <boost/random/geometric_distribution.hpp>

class RandomJSON
{
  
public:

  RandomJSON(unsigned seed, float dupProb):
    m_rng(seed),
    m_dupProb(dupProb),
    m_maxDepth(100),
    m_geoprob(.01)
  {}

  JSONelement operator () (std::vector<std::string> & duplicates)
  {
    return randomObject(duplicates,0);
  }
  
private:

  JSONelement randomElement(std::vector<std::string> & duplicates,
			    unsigned depth)
  {

    unsigned min = 0;
    if (depth > m_maxDepth || m_geoprob > 0.99999) min = 2;
    
    boost::variate_generator <boost::random::mt19937 &, uniform >
      unigen(m_rng, uniform(min,5));
    
    unsigned elType=unigen();
    
    switch (elType)
      {
      case 0:
	return randomArray(duplicates, depth+1);
      case 1:
	return randomObject(duplicates, depth+1);
      case 2:
	return randomString();
      case 3:
	return randomInt();
      case 4:
	return randomBool();
      case 5:
	return randomFloat();
      default:
      assert(0);
      };
  }


  std::string randomName()
  {
    boost::variate_generator <boost::random::mt19937 &, uniform>
      chargen(m_rng, uniform((int)'a',(int)'z'));

    boost::variate_generator <boost::random::mt19937 &, geometric>
      lengen(m_rng, geometric(.2));

    m_geoprob += 0.01;

    unsigned length = lengen()+1;
    char name[length+1];
    for (unsigned i = 0; i < length; i++)
      name[i] = chargen();
    name[length]=0;
    return name;
  }

  JSONelement randomObject(std::vector<std::string> & duplicates,
			   unsigned depth)
  {
    boost::variate_generator <boost::random::mt19937 &, geometric>
      lengen(m_rng, geometric(m_geoprob));
    boost::variate_generator <boost::random::mt19937 &, uniform>
      dupgen(m_rng, uniform(0, 100));

    m_geoprob += 0.01;
    
    unsigned numElements = lengen();
    JSONlist result;
    
    std::vector<std::string> usedNames;
    
    for (unsigned i = 0; i < numElements; i++)
      {
	std::string elementName;
	if (usedNames.size() && dupgen() < m_dupProb * 100)
	  {
	    boost::variate_generator <boost::random::mt19937 &, uniform>
	      choose(m_rng, uniform(0, usedNames.size()-1));

	    elementName = usedNames[choose()];
	    duplicates.push_back(elementName);
	  }
	else
	  {
	    elementName = randomName();
	    bool dup = false;
	    for (unsigned i = 0; i < usedNames.size(); i++)
	      if (elementName == usedNames[i])
		{
		  dup = true;
		  break;
		}

	    if (dup)
	      duplicates.push_back(elementName);
	    else
	      usedNames.push_back(elementName);
	  }

	JSONnamedElement nel(elementName, randomElement(duplicates, depth));
	result.addElement(nel);

      }
    return JSONobject(result);
  }
    
  JSONelement randomArray(std::vector<std::string> & duplicates,
			  unsigned depth)
  {
    boost::variate_generator <boost::random::mt19937 &, geometric>
      lengen(m_rng, geometric(m_geoprob));

    unsigned numElements=lengen();
    JSONarray result;

    for (unsigned i = 0; i < numElements; i++)
      result.addElement(randomElement(duplicates, depth));

    return result;
  }

  JSONelement randomString()
  {
    return JSONstring(randomName());
  }

  JSONelement randomInt()
  {
    boost::variate_generator <boost::random::mt19937 &, geometric>
      numgen(m_rng, geometric(.6));

    return JSONint(numgen());
  }

  JSONelement randomFloat()
  {
    boost::variate_generator <boost::random::mt19937 &, unifloat>
      numgen(m_rng, unifloat(0, FLT_MAX));

    return JSONfloat(numgen());
  }

  JSONelement randomBool()
  {
    boost::variate_generator <boost::random::mt19937 &, uniform>
      boolgen(m_rng, uniform(0, 1));

    if (boolgen())
      return JSONlogical(true);
    else
      return JSONlogical(false);
  }

  
private:
  
  typedef boost::random::uniform_int_distribution <> uniform;
  typedef boost::random::uniform_real_distribution <> unifloat;
  typedef boost::random::geometric_distribution <> geometric;

  boost::mt19937 m_rng;
  float          m_dupProb;
  int            m_maxDepth;
  float          m_geoprob;
};
