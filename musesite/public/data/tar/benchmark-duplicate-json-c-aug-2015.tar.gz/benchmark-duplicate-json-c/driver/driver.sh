#!/bin/sh
#
#  The command line argument is the file to test.
#

for i in `seq 400001 401000`;
do
    ./generate $i dups > testfile;
    "$1" testfile | sort | uniq > results
    if [ "$(sort dups | uniq | diff - results)" != "" ];
    then
	echo "failed."
    fi
done
	 
	       
	 
