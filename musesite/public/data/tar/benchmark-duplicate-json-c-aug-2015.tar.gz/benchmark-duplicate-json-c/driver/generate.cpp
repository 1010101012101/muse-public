#include <iostream>
#include <fstream>

#include "RandomJSON.h"

main(int argc, char **argv)
{
  RandomJSON j(atoi(argv[1]), 0.12);
  std::vector<std::string> duplicates;
  JSONelement el = j(duplicates);
  el.printMe(std::cout, 0);
  std::cout << "\n";
  std::ofstream dupls;
  dupls.open(argv[2]);
  for (unsigned i = 0; i < duplicates.size(); i++)
    dupls << duplicates[i] << "\n";
  dupls.close();
}
