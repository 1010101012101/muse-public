#include <string>
#include <vector>
#include <set>
#include <sstream>
#include <iostream>
#include <fstream>
#include "filereadstream.h"
#include "rapidjson/reader.h"
#include "rapidjson/error/en.h"


using namespace rapidjson;

template <class Encoding, class Ch>
struct MyHandler:  public rapidjson::BaseReaderHandler<Encoding>

{
  
public:

  MyHandler():
    m_stackDepth(0)
  {
    m_keyStack.resize(10);
  }
  
  typedef uint16_t SizeType;


  bool Key(const Ch* ch, SizeType siz, bool copy) 
  {
    (void)ProcessString(ch, siz);
    return true;
  }

  int ProcessString(const Ch* str, SizeType length) 
  {
    static const char hexDigits[] = "0123456789ABCDEF";
    static const char escape[256] = {
#define Z16 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
      //0 1 2 3 4 5 6 7 8 9 A B C D E F
      'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'b', 't', 'n', 'u', 'f', 'r', 'u', 'u', // 00
      'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', // 10
      0, 0, '"', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 20
      Z16, Z16, // 30~4F
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,'\\', 0, 0, 0, // 50
      Z16, Z16, Z16, Z16, Z16, Z16, Z16, Z16, Z16, Z16 // 60~FF
#undef Z16
    };

    
    std::stringstream stream;
    unsigned numProcessed = 0;
    
    for (const char* p = str; p != str + length; ++p) {
      if ((sizeof(char) == 1 || *p < 256) && escape[(unsigned char)*p]) {
	stream << '\\';
	stream << escape[(unsigned char)*p];
	if (escape[(unsigned char)*p] == 'u') {
	  stream << '0';
	  stream << '0';
	  stream << '0';
	  stream << hexDigits[(*p) >> 4];
	  stream << hexDigits[(*p) & 0xF];
	}
      }
      else
	stream << *p;

      numProcessed++;
    }

    if (m_keyStack[m_stackDepth].find(stream.str()) != m_keyStack[m_stackDepth].end())
      std::cout << stream.str() << "\n";

    m_keyStack[m_stackDepth].insert(stream.str());
    return numProcessed;
  }

  bool StartObject()
  {
    m_stackDepth++;

    if (m_stackDepth >= m_keyStack.size())
      m_keyStack.resize(m_stackDepth+1);
    else
      m_keyStack[m_stackDepth] = KeySet();
	
    return true;
  }

  bool EndObject(SizeType length)
  {
    m_stackDepth--;
    
    return true;
  }

private:

  struct Level {
    Level(bool inArray_) : inArray(inArray_), valueCount(0) {}
    bool inArray; //!< true if in array, otherwise in object
    size_t valueCount; //!< number of values in this level
  };

 
  typedef std::set<std::string> KeySet;
  std::vector<KeySet> m_keyStack;
  unsigned m_stackDepth;
  
  static const size_t kDefaultLevelDepth = 32;
};

int main(int argc, char **argv)
{ 
  typedef rapidjson::UTF8<char> Encoding;

  char buffer[BUFSIZ];

  /* @bug fails to check if argv[1] exists @bug */
  
  FILE *infile = fopen(argv[1], "r");
  FileReadStream fs(infile, buffer, BUFSIZ-1);
  
  MyHandler<Encoding, char> handler;
  Reader reader;
  
  reader.Parse(fs, handler);

  return 0;
}
