public class Runner {
    public static void main(String[] args) {
        Matrix m1 = Matrix.createMatrix(3,3);
        Matrix m2 = Matrix.createMatrix(3,3);
        System.out.println("First matrix: ");
        m1.print();
        System.out.println("Second matrix: ");
        m2.print();
        Matrix result = Matrix.multiplication(m1, m2);
        System.out.println("Result matrix: ");
        result.print();
    }
}
