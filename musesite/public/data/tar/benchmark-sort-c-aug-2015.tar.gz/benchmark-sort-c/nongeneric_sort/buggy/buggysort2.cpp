/* shell sort from http://stackoverflow.com/questions/13114865/im-programming-sorting-algorithm-shellsort-where-is-bug
 */


int shellsort( int ai_numbers[], const int ci_count ){

    int i, j, temp, counter = 0, inc;
    inc = ci_count / 2;

    while ( inc > 0 )
    {
      /* @bug As pointed out on the original stackoverflow page, the algorithm
	 seems to have been typed in from a source that assumes 1-based
	 arrays instead of zero-based arrays. The initialization of this
	 for loop is off by one. @bug 
      */
    

        for ( i = inc + 1; i < ci_count ; i++)
        {
            temp = ai_numbers[i];
            j = i;

	    /* @bug The comparison of j and inc is also off by one. @bug */
	    
            while ( j > inc && ai_numbers[j - inc] > temp )
            {
                ai_numbers[j] = ai_numbers[j - inc];
                j = j - inc;
                counter++;
            }
            ai_numbers[j] = temp;
        }

        inc = (int) (inc / 2.2);  /* @bug the divisor should be two. There are
				     also other ways to define gap sequences
				     but this sequence, N/2, N/2.2, N/2.2 ...
				     isn't one of them. The first gap is 
				     defined up on line 8 as N/2.
				  */
    }
    return counter;
}

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>

int main(int argc, char **argv)
{
  char buffer[512];
  
  std::vector<int> entries;
  while (fgets(buffer, 511, stdin))
  {
    entries.push_back(atoi(buffer));
  }

  int numbers[entries.size()];
  for (unsigned i = 0; i < entries.size(); i++)
    {
      numbers[i] = entries[i];
    }
  
  shellsort(numbers, entries.size());

  for (unsigned i = 0, end = entries.size(); i != end; i++)
  {
    std::cout << numbers[i] << "\n";
  }
}
