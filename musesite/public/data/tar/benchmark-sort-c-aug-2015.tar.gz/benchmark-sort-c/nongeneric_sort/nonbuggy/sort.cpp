#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>

#include "QuickSortData.h"

int main(int argc, char **argv)
{
  char buffer[512];
  
  std::vector<int> entries;
  while (fgets(buffer, 511, stdin))
  {
    entries.push_back(atoi(buffer));
  }

  QuickSortData(entries);

  for (unsigned i = 0, end = entries.size(); i != end; i++)
  {
    std::cout << entries[i] << "\n";
  }
}
