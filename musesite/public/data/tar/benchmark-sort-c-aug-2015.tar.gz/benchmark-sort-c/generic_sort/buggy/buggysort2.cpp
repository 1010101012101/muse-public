#include <stdio.h>
#include <vector>
#include <iostream>



#include "QuickSortData.h"



#include "number.h"

int main(int argc, char **argv)
{
  char buffer[512];
  
  std::vector<number> entries;
  while (fgets(buffer, 511, stdin))
  {
    entries.push_back(number(buffer));
  }

  QuickSortData(entries);

  for (unsigned i = 0, end = entries.size(); i != end; i++)
  {
    std::cout << entries[i].data() << "\n";
  }
}
