#include <stdio.h>
#include <vector>
#include <iostream>

#include "QuickSortData.h"

#include "utf8string_2.h"

int main(int argc, char **argv)
{
  char buffer[512];
  
  /* @bug the sort code assumes that the data() method of the whose
     members we're sorting returns the things we're trying to sort.
     But in the case of the utf8string method, data() returns a pointer
     to the backing buffer (as it does with std::string). @bug
  */

  std::vector<utf8string_2> entries;
  while (fgets(buffer, 511, stdin))
  {
    entries.push_back(utf8string_2::from_string(buffer));
  }

  QuickSortData(entries);

  for (unsigned i = 0, end = entries.size(); i != end; i++)
  {
    std::cout << entries[i].str();
  }
}
