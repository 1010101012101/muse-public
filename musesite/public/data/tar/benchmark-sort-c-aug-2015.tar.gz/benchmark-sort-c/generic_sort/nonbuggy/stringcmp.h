#pragma once

#include <string>

class stringcmp
{
 public:

  stringcmp()
  {}

  stringcmp(const char *buff):
    m_string(buff)
  {}

  stringcmp(const std::string & str):
    m_string(str)
  {}

  bool operator < (const stringcmp & rhs) const
  {
    return (m_string.compare(rhs.str()) < 0);
  }

  bool operator == (const stringcmp & rhs) const
  {
    return (m_string.compare(rhs.str()) == 0);
  }

  const std::string & str() const
  {
    return m_string;
  }
  
private:

  const std::string m_string;
};
  
