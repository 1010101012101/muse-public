template<class SortType>
void QuickSortData(std::vector<SortType> & Data, int low, int high)
{
  SortType Tmp;
  int partition, bottom, top;

  if (low >= high) return;

  if ((high - low) == 1)
    {
      if (Data[high].data() < Data[low].data())
	{
	  // Flip 'em
	  Tmp = Data[low];
	  Data[low] = Data[high];
	  Data[high] = Tmp; 	
	}

      //return;
    }
  
  // Pick a partition element and move it to the end of the array
  partition = (high+low)/2;
  Tmp = Data[high];
  Data[high] = Data[partition];
  Data[partition] = Tmp;
  
  bottom = low;
  top = high-1;
  
  while(bottom < top)
    {
      //                                              Partition Element
      while(bottom <= top && !(Data[high].data() < Data[bottom].data()))
	bottom++;
      
      while(bottom < top && 
	    (Data[high].data() < Data[top].data() ||
	     Data[high].data() == Data[top].data()))
					
	top--;
      
      if (bottom < top)
	{
	  // Flip 'em
	  Tmp = Data[bottom];
	  Data[bottom] = Data[top];
	  Data[top] = Tmp; 	
	}
    }
  
  // Put the pivot in it's final spot
  Tmp = Data[high];
  Data[high] = Data[bottom];
  Data[bottom] = Tmp;
  
  QuickSortData(Data, low, bottom-1);
  QuickSortData(Data, bottom+1, high);	
}


template<class SortType>
void QuickSortData(std::vector<SortType> & Data)
{
  QuickSortData(Data, 0, Data.size()-1);
}
