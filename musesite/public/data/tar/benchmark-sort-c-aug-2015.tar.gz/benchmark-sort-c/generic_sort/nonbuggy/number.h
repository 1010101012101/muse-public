#pragma once
#include <stdlib.h>

class number{

public:

  number():
    m_number(0)
  {}

  
  number(int n):
    m_number(n)
  {}

  number(char *str):
    m_number(atoi(str))
  {}
  
  int data() const
  {
    return m_number;
  }

private:

  int m_number;
  
};
