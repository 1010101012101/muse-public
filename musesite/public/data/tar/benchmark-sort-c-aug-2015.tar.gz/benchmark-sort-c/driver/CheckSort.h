template <class T, bool increasing>
class CheckSort
{
  
 public:

  bool operator () (const std::vector<T> &data) const
  {
    if (data.size() == 0)
      return true;
    
    T previous = data[0];
    
    for (unsigned i = 1; i < data.size(); i++)
      {
	if (increasing && data[i] < previous)
	  return false;
	if (!increasing && previous < data[i])
	  return false;

	previous = data[i];
      }

    return true;
  }
};
