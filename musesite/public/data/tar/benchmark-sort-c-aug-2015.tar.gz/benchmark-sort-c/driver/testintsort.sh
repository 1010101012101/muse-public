#!/bin/bash
#
# Usage: testintsort <num tests> <seed> <executable>
#
#  Test a program that sorts integers from stdin and prints them to
# stdout in increasing order.
#

for i in $(seq 0 $1);
do
    ./randomint $(($2 + $i)) > integer_tests
    cat integer_tests | $3 | ./checkintsort
    if [[ $? != 0 ]]; then exit 1; fi
done
