/***************************************
 *
 *  A simple filter to check whether the data on stdin is sorted in
 * increasing order.
 *
 ******/


#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include "CheckSort.h"

int main()
{
  char buffer[512];
  std::vector<int> numbers;

  while (fgets(buffer, 511, stdin))
    {
      numbers.push_back(atoi(buffer));
    }

  CheckSort<int, true> checker;
  if (checker(numbers))
    {
      printf("passed\n");
      return (0);
    }
  else
    {
      printf("failed\n");
      return (1);
    }
}
