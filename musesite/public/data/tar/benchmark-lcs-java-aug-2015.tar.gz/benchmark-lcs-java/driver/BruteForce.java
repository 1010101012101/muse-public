/******************************
 *
 *  This is a brute-force LCS implementation to use for testing.
 * I couldn't think of a clever way to check the correctness of
 * a claimed longest common substring without actually checking
 * if longer ones exists, but the idea of this code is to do the
 * check in such a straightforward way that the code can be verified
 * by inspection.
 * 
 *  The challenge problem asks for -some- longest common substring, 
 * so the test is to check that the claimed substring is contained
 * on both of the two strings it's supposedly common to, and that there
 * is no other common substring that's longer. The length of the 
 * longest common substring is obtained by a brute-force search over
 * all possible pairs of starting positions for a common substring,
 * and for each pair of positions we find the longest common substring
 * starting at that pair of positions.
 *
 *****/


import java.lang.Integer;
import java.util.Vector;
import static java.lang.System.*;

public class BruteForce
{
    private static int
	LongestCommonPrefix(final Vector<Integer> first, 
			    final Vector<Integer> second, 
			    int startFirst, int startSecond)
    {
	int len = first.size()-startFirst;
	if (len > second.size()-startSecond)
	    len = second.size()-startSecond;
	
	int result = 0;
	int i = 0;
	for (; i < len; i++)
	    {
		if (first.get(i+startFirst) != second.get(i+startSecond))
		    break;
	    }
	
	return i;
    }

    private static int
	LongestCommonSuffix(final Vector<Integer> first, 
			    final Vector<Integer> second)
    {
	int result = 0;
  
	for (int i = 0; i < first.size(); i++)
	    {
		for (int j = 0; j < second.size(); j++)
		    {
			int prefix =
			    LongestCommonPrefix(first, second, i, j);
			if (prefix > result)
			    result = prefix;
		    }
	    }
	
	return result;
    }

    private static void printLines(final Vector<Integer> seq1, 
				   final Vector<Integer> seq2,
				   final Vector<Integer> result)
	
    {
	for (int i = 0; i < seq1.size(); i++)
	    out.print(seq1.get(i) + " ");
	out.println("\n");
  
	for (int i = 0; i < seq2.size(); i++)
	    out.print(seq2.get(i) + " ");
	out.println("\n");
  
	for (int i = 0; i < result.size(); i++)
	    out.print(result.get(i) + " ");
	out.println("\n");
    }

    private static Boolean vectorContains(final Vector<Integer> first, 
					 final Vector<Integer> second)
    {
	int m = first.size();
	int n = second.size();

	if (n == 0)
	    return true;
	
	for (int i = 0; i < first.size(); i++)
	    {
		Boolean found = true;

		for (int j = 0, jj=i; j < second.size(); j++, jj++)
		    {
			if (first.get(jj) != second.get(j))
			    {
				found = false;
				break;
			    }
		    }

		if (found)
		    return true;
	    }

	return false;
    }

    public static Boolean testLCS(final Vector<Integer> first, 
				  final Vector<Integer> second,
				  final Vector<Integer> claimedLCS)
    {
	if (!vectorContains(first,claimedLCS))
	    {
		printLines(first, second, claimedLCS);
		out.println("Claimed LCS isn't a substring of first string");
		return false;
	    }
  
	if (!vectorContains(first,claimedLCS))
	    {
		printLines(first, second, claimedLCS);
		out.println("Claimed LCS isn't a substring of second string");
		return false;
	    }

	int lcsSize = LongestCommonSuffix(first, second);
	if (lcsSize > claimedLCS.size())
	    {
		printLines(first, second, claimedLCS);
		out.println("Actual LCS has length " + lcsSize);
		return false;
	    }
	
	return true;
    }
};

