import static java.lang.System.*;
import java.lang.Integer;
import java.util.Vector;
import java.util.ArrayList;
// adapted from http://www.geeksforgeeks.org/longest-common-substring/

/* Dynamic Programming implementation of LCS problem */

public class LCS2 implements ComputeLCS
{
    private void
	initializeArray(ArrayList<ArrayList<Pair <Integer, Integer>>> LCSuff,
			int m, int n)
    {
	for (int i = 0; i < m; i++)
	    {
		ArrayList<Pair<Integer, Integer>> temp =
		    new ArrayList<Pair<Integer, Integer>>();
		
		for (int j = 0; j < n; j++)
		    {
			temp.add(new Pair<Integer, Integer>(0,0));
		    }

		LCSuff.add(temp);
	    }
    }
    
    public void LCSubStr(final Vector<Integer> X,
		      final Vector<Integer> Y,
		      int m, int n, Vector<Integer> result)
    {
	// Create a table to store lengths of longest common suffixes of
	// substrings.   Notethat LCSuff[i][j] contains length of longest
	// common suffix of X[0..i-1] and Y[0..j-1]. The first row and
	// first column entries have no logical meaning, they are used only
	// for simplicity of program
	
	/**************************************************************
	 * 
	 *  Each table entry is a std::pair where the first elemnt stores the
	 * start of the substring in X, and the second element stores its
	 * length. For legibility, if LCSuff[i][j] isn't part of any common
	 * substring, we set its first element to -1 as well as redundantly
	 * setting the second element to zero.
	 *
	 ****/
	
	ArrayList<ArrayList<Pair <Integer, Integer>>> LCSuff =
	    new ArrayList<ArrayList<Pair<Integer,Integer>>>();

	initializeArray(LCSuff, m+1, n+1);
	
	// To store length of the longest common substring
	Pair <Integer,Integer> max = new Pair<Integer,Integer>(-1,0);


	/* Following steps build LCSuff[m+1][n+1] in bottom up fashion. */
	for (int i=0; i<=m; i++)
	    {
		for (int j=0; j<=n; j++)
		    {
			if (i == 0 || j == 0)
			    {
				LCSuff.get(i).get(j).setFirst(-1);
				LCSuff.get(i).get(j).setSecond(0);
			    }	    
			else if (X.get(i-1) == Y.get(j-1))
			    {
				LCSuff.get(i).get(j).
				    setSecond(LCSuff.get(i-1).
					      get(j-1).second() + 1);

				if (LCSuff.get(i-1).get(j-1).first() == -1)
				    LCSuff.get(i).get(j).setFirst(i-1);
				else
				    LCSuff.get(i).get(j).
					setFirst(LCSuff.get(i-1).
						 get(j-1).first());
		
				if (LCSuff.get(i).get(j).second() > max.second())
				    max = LCSuff.get(i).get(j);
			    }
			else
			    LCSuff.get(i).set(j,
					      new Pair<Integer, Integer>(-1,0));
		    }
	    }
    
	int start = max.first();
	int end = start+max.second();
    
	for (int i =  start; i < end; i++)
	    result.add(X.get(i));
    }


    public void LCS(final Vector<Integer> X,
	     final Vector<Integer> Y,
	     Vector<Integer> result)
    {
	LCSubStr(X, Y, X.size(), Y.size(), result);
    }

    public static void main(String [] args)
    {
	LCS2 lcs = new LCS2();

	Driver driver =
	    new Driver(Integer.parseInt(args[0]),
		       Integer.parseInt(args[1]));
	if (!driver.driver(lcs))
	    out.println("failed\n");
	else
	    out.println("passed\n");
    }
};


