/* original courtesy of player1537, http://www.cemetech.net/forum/viewtopic.php?t=5401 */

import java.util.List;
import static java.lang.Math.*;
import static java.lang.System.*;

public class BresenhamFixed implements Bresenham
{

    public void drawLine(final Integer X1, final Integer Y1,
			 List<Pair<Integer, Integer>> result)
    {
	Integer x1 = X1, y1 = Y1;
	Integer x0 = 0, y0 = 0;

	Boolean steep = abs(y1 - y0) > abs(x1 - x0);
	Integer a;
	if (steep)
	    {
		a = x0; x0 = y0; y0 = a;
		a = x1; x1 = y1; y1 = a;
	    }
	if (x0 > x1)
	    {
		a = x0; x0 = x1; x1 = a;
		a = y0; y0 = y1; y1 = a;
	    }
	
	Integer deltax = x1 - x0;
	Integer deltay = abs(y1 - y0);
	float error = 0;
	
	float deltaerr = (float)deltay / (float)deltax;
	int ystep;
	if (y0 < y1)
	    ystep = 1;
	else
	    ystep = -1;
	
	int y = y0;
	for (int x = x0;x <= x1;x++)
	    {
		if (steep)
		    result.add(new Pair<Integer, Integer>(y,x));
		else
		    result.add(new Pair<Integer, Integer>(x,y));
		error = error + deltaerr;
		if (error >= 0.5)
		    {
	     y += ystep;
	     error = error - 1;
		    }
	    }
    }

    public static void main(String [] args)
    {
	BresenhamFixed b = new BresenhamFixed();
	TestDriver td = new TestDriver(Integer.parseInt(args[0]),
				       Integer.parseInt(args[1]));
	if (td.test(b))
	    out.println("passed");
	else
	    out.println("failed");
    }	    
};


