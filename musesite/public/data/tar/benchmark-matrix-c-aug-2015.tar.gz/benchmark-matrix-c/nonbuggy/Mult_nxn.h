#pragma once

/*************************************************
 *
 *  right multiply a MxN matrix by a Nx1 vector. 
 *
 *****/

#include "MatrixMult.h"

class Mult_nxn: public MatrixMult
{
 public:

  void Multiply
    (const SortofMatrix & A, const SortofMatrix & B,
     SortofMatrix & result)
  {
    unsigned rows = A.size();
    unsigned midcolumns = B.size();

    unsigned columns = B[0].size();
    
    for (unsigned i = 1; i < midcolumns; i++)
    {
      assert (B[i].size() == columns);
    }

    result.clear();
    result.resize(rows);
    for (unsigned i = 0; i < columns; i++)
      {
	result[i].resize(rows);
      }
    

    for (unsigned i = 0; i < rows; i++)
      {
	for (unsigned j = 0; j < columns; j++)
	  {
	    	long sum = 0;
		for (unsigned k = 0; k < midcolumns; k++)
		  sum += A[i][k]*B[k][j];

		result[i][j] = sum;
	  }
      }
  }
};
