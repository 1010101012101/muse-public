#include <iostream>

/******************************************
 *
 *  This is a test wrapper that uses libdriver.a to test the matrix
 * multiplication method in the class Mult_nxn.
 *
 *****/

#include <boost/program_options.hpp>
#include "Mult_nxn.h"
#include "driver.h"

namespace po = boost::program_options;
bool parseOptions(unsigned argc, char **argv,
		  unsigned & magnitude, unsigned & numTests, long &seed,
		  unsigned &size)
{
  po::options_description desc("Allowed options");
  desc.add_options()
    ("help,h", "print this message")
    ("magnitude,m", po::value<unsigned>(),
     "maximum magnitude of matrix entries")
    ("numTests,n", po::value<unsigned>(), "Number of tests")
    ("seed,s", po::value<long>(), "random number seed")
    ("Size,S", po::value<unsigned>(),
     "mean number of rows/columns in matrices used for testing");

  po::variables_map vm;    
  po::store(po::parse_command_line(argc, argv, desc), vm);
  po::notify(vm);    

  if (vm.count("help")) {
    std::cout << desc << "\n";
    return 1;
  }

  if (vm.count("magnitude"))
    magnitude=vm["magntude"].as<unsigned>();
  else
    magnitude=4;

  if (vm.count("numTests"))
    numTests=vm["numTests"].as<unsigned>();
  else
    numTests=100;

  if (vm.count("seed"))
    seed=vm["seed"].as<long>();
  else
    seed = 1232321;

  if (vm.count("Size"))
    size=vm["size"].as<unsigned>();
  else
    size=10;
  
  return true;
}

  
	       
int main(int argc, char **argv)
{

  unsigned magnitude = 0;
  unsigned numTests = 0;
  long seed = 0;
  unsigned size = 0;
  unsigned ctests = 12;
  
  if (!parseOptions(argc, argv, magnitude, numTests, seed, size))
    return 0;

  Mult_nxn mm;
  if (driver(mm, seed, magnitude, numTests, size, ctests))
    std::cout << "passed\n";
  else
    std::cout << "failed\n";

  exit(0);
}
