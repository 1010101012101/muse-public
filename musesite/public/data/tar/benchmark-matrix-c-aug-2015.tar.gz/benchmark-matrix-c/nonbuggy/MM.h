#include <iostream>

#include <dlib/matrix.h>

#include "MatrixMult.h"

using namespace dlib;

class MM: public MatrixMult
{

  template <class T>
  void getSize(const std::vector< std::vector<T> >  & m,
	       unsigned & rows, unsigned & columns)
  {
    rows = m.size();
    columns = 0;
    
    unsigned colsize;
    
    for (unsigned i = 0; i < rows; i++)
      if ((colsize = m[i].size()) > columns)
	columns = colsize;
  }
  


  template <class T>
  void transferData(const std::vector< std::vector<T> >  & m,
		    matrix<T> & result)
  {
    unsigned rows;
    unsigned columns;
    
    getSize(m, rows, columns);
    result.set_size(rows, columns);
    
    for (unsigned j = 0; j < rows; j++)
      for (unsigned i = 0; i < columns; i++)
	{
	  if (m[j].size() > i)
	    result(j,i) = m[j][i];
	  else
	    result(j,i) = 0;
	}
  }
  
  
  
  template <class T>
  void mmult(const std::vector< std::vector<T> >  & m1,
	     const std::vector< std::vector<T> >  & m2,
	     std::vector< std::vector<T> >  & result)
  {
    matrix<T> first;
    matrix<T> second;
    matrix<T> product;
    
    
    transferData(m1, first);
    transferData(m2, second);
    
    product = first * second;
    
    result.resize(product.nc());
    for (unsigned j = 0; j < product.nc(); j++)
      {
	result[j].resize(product.nr());
	for (unsigned i = 0; i < product.nr(); i++)
	  {
	    result[j][i] = product(j,i);
	  }
      }
  }


public:
  
  void Multiply(const SortofMatrix & first,
		const SortofMatrix & second,
		SortofMatrix & result)
  {
    mmult(first, second, result);
  }
};

