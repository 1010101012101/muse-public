#pragma once

#include "MatrixMult.h"

class Mult_nxn_buggy: public MatrixMult
{
 public:

  void Multiply
    (const SortofMatrix & A, const SortofMatrix & B,
     SortofMatrix & result)
  {

    /* @bug The idea is that this multiplication routine assumes a column-
       major representation for the matrices. Unfortunately I don't have
       a good way to check whether this is actually correct multiplication
       for column-major representation. An aesthetic flaw of this bug is that
       the the dimensions of the matrices don't match up unless they're 
       square, but that can be taken care of to some extent by taking advantage
       of the fact that C++ allows out-of-bounds reads on templatized 
       containers by default. It's just necessary to rewrite the code to avoid 
       random-access writes to vectors, since those are checked. That's what 
       I tried to do below. Presumably this can core-dump sometimes. @bug
    */
    

    unsigned rows = A[0].size();
    unsigned midcolumns = B[0].size();

    unsigned columns = B.size();

    /*
    result.clear();
    result.resize(columns);
    for (unsigned i = 0; i < columns; i++)
      {
	result[i].resize(rows);
      }
    */

    for (unsigned j = 0; j < columns; j++)
      {
	result.push_back(std::vector<long>());
	
	for (unsigned i = 0; i < rows; i++)
	{
	  long sum = 0;
	  for (unsigned k = 0; k < midcolumns; k++)
	    sum += A[k][i]*B[j][k];
	  
	  result[j].push_back(sum);
	}
      }

    /*
    for (unsigned i = 0; i < rows; i++)
      {
	for (unsigned j = 0; j < columns; j++)
	  {
	    	long sum = 0;
		for (unsigned k = 0; k < midcolumns; k++)
		  sum += A[k][i]*B[j][k];

		result[j][i] = sum;
	  }
      }
    */
  }
};
