
#include <dlib/matrix.h>

#include "MatrixMult.h"

using namespace dlib;

class MM: public MatrixMult
{

  template <class T>
  void getSize(const std::vector< std::vector<T> >  & m,
	       unsigned & rows, unsigned & columns)
  {
    rows = m.size();
    columns = 0;
    
    unsigned colsize;
    
    for (unsigned i = 0; i < rows; i++)
      if ((colsize = m[i].size()) > columns)
	columns = colsize;
  }
  


  template <class T>
  void transferData(const std::vector< std::vector<T> >  & m,
		    matrix<T> & result)
  {
    unsigned rows;
    unsigned columns;
    
    getSize(m, rows, columns);
    result.set_size(rows, columns);
    
    for (unsigned j = 0; j < rows; j++)
      for (unsigned i = 0; i < columns; i++)
	{
	  if (m[j].size() > i)
	    result(j,i) = m[j][i];
	  else
	    result(j,i) = 0;
	}
  }
  
  
  
  template <class T>
  void mmult(const std::vector< std::vector<T> >  & m1,
	     const std::vector< std::vector<T> >  & m2,
	     std::vector< std::vector<T> >  & result)
  {
    matrix<T> first;
    matrix<T> second;
    matrix<T> product;
    
    
    transferData(m1, first);
    transferData(m2, second);
    
    product = first * second;

    /* @bug: in dlib, NC and NR are compile-time template arguments
       supplying the number of columns and number of rows in the 
       matrix. However, giving the matrix dimensions at compile time
       is only an option to help with optimization. Our driver doesn't
       provide them, since the challenge problem implicitly asks for the 
       dimensions of the matrix to be provided at runtime. For that case, 
       NC and NR aren't valid. @bug
    */
    
    result.resize(product.NC);
    for (unsigned j = 0; j < product.NC; j++)
      {
	result[j].resize(product.NR);
	for (unsigned i = 0; i < product.NR; i++)
	  {
	    result[j][i] = product(j,i);
	  }
      }
  }


public:
  
  void Multiply(const SortofMatrix & first,
		const SortofMatrix & second,
		SortofMatrix & result)
  {
    mmult(first, second, result);
  }
};
