#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#include <sstream>
#include <fstream>

#include <boost/algorithm/string.hpp>
#include "RishiDewan33.h"

void
RishiDewan33::
spawnTest(const std::string & keyFile, const std::string & textFile,
	  const TestInfo & testInfo, Task task)
{
  const char * argv[10];
  argv[0] = "java";
  argv[1] = "AES";
  argv[2] = (task == Encode)? "e": "d";
  argv[3] = "-length";
  argv[4] = (testInfo.keySize() == Key_128)? "128": "256";
  argv[5] = "-mode";
  argv[6] = (testInfo.mode() == CBC)? "cbc": "ecb";
  argv[7] = keyFile.c_str();
  argv[8] = textFile.c_str();
  argv[9] = 0;

  pid_t pid = fork();
  if (pid == 0)
    {

      /*********************************
       *
       *  The reason for not using execv here is that its
       * argv argunent is a char * const[] and not a const char * const[]
       * as it should be. Even if I wasn't too lazy to create
       * copies of all the strings in the argv array, after all that
       * trouble the call still wouldn't technically be safe.
       *
       *****/

      execlp("/usr/bin/java", argv[0], argv[1], argv[2], argv[3],
	    argv[4], argv[5], argv[6], argv[7], argv[8], 0);
    }
  else
    {
      int exit_status;

      waitpid( pid, &exit_status, 0);
    }
}

bool 
RishiDewan33::
encode(const TestInfo & testInfo, std::string & result)
{
  result.clear();
  return encdec(testInfo, result, Encode);
}

bool 
RishiDewan33::
decode(const TestInfo & testInfo, std::string & result)
{
  result.clear();
  return encdec(testInfo, result, Decode);
}

bool
RishiDewan33::
encdec(const TestInfo & testInfo,
       std::string & result,
       Task task) 
{
  if (!testInfo.haveCount())
    return false;
  
  std::stringstream keyFileName;
  keyFileName << "key_" << testInfo.count();
  
  std::fstream keyFile;
  keyFile.open(keyFileName.str().c_str(), std::ios_base::out);
  if (!keyFile.is_open())
    {
      std::cerr << "Couldn't open " << keyFileName.str() << "\n";
      return false;
    }

  keyFile << testInfo.key() << "\n";
  if (testInfo.mode() == CBC)
    keyFile << testInfo.IV() << "\n";
  keyFile.close();


  if (task == Encode)
    {
      std::stringstream textFileName;
      textFileName << "pt_" << testInfo.count();
      
      std::fstream textFile;
      textFile.open(textFileName.str().c_str(), std::ios_base::out);  
      if (!textFile.is_open())
	{
	  std::cerr << "Couldn't open " << textFileName.str() << "\n";
	  return false;
	}


      /**********************************
       * 
       *   Apparently in just this one case the algorithm fails to
       * process text with lowercase hex digits. We'll take that as
       * a precondition rather than a bug since it's not relevant to
       * the actual encryption algorithm.
       *
       *******/

      std::string textString =
	boost::to_upper_copy<std::string>(testInfo.plainText());
      
      for (unsigned j = 0; j < textString.size(); j+= 32)
	textFile << textString.substr(j, 32)
		 << "\n";
      
      textFile.close();
      
      spawnTest(keyFileName.str(), textFileName.str(), testInfo, Encode);
      
      std::stringstream encFileName;
      encFileName << textFileName.str() << ".enc";
      
      std::fstream encFile;
      encFile.open(encFileName.str().c_str());
      if (!encFile.is_open())
	{
	  std::cerr << "Couldn't open " << encFileName.str() << "\n";
	  perror(NULL);
	  return false;
	}
      

      std::string encrypted;
      while (getline(encFile, encrypted))
	result += encrypted;
      
      encFile.close();
      
      return true;
    }
  else // decode
    {
      std::stringstream cryptFileName;
      cryptFileName << "ct_" << testInfo.count();
      
      std::fstream cryptFile;
      cryptFile.open(cryptFileName.str().c_str(), std::ios_base::out);  
      if (!cryptFile.is_open())
	{
	  std::cerr << "Couldn't open " << cryptFileName.str() << "\n";
	  return false;
	}

      const std::string & cipher =
	boost::to_upper_copy<std::string>(testInfo.cipherText());

      for (unsigned i = 0; i < cipher.size(); i+=32)
	{
	  cryptFile << cipher.substr(i, 32) << "\n";
	}

      cryptFile.close();
      
      spawnTest(keyFileName.str(), cryptFileName.str(), testInfo, Decode);
      
      std::stringstream decFileName;
      decFileName << cryptFileName.str() << ".dec";
      
      std::fstream decFile;
      decFile.open(decFileName.str().c_str());
      if (!decFile.is_open())
	{
	  std::cerr << "Couldn't open " << decFileName.str() << "\n";
	  perror(NULL);
	  return false;
	}
      
      std::string decrypted;
      while (getline(decFile, decrypted))
	result += decrypted;
     
      decFile.close();
      
      return true;
    }      
}

#ifdef OBSOLETE
bool
RishiDewan33::
doTestMaybe(const TestInfo & testInfo, TestState state, bool & failed)
{
  failed = false;

  if (!testInfo.haveCount())
    return false;
  
  std::stringstream keyFileName;
  keyFileName << "key_" << testInfo.count();
  
  std::fstream keyFile;
  keyFile.open(keyFileName.str().c_str(), std::ios_base::out);
  if (!keyFile.is_open())
    {
      std::cerr << "Couldn't open " << keyFileName.str() << "\n";
      return false;
    }

  keyFile << testInfo.key() << "\n";
  if (testInfo.mode() == CBC)
    keyFile << testInfo.IV() << "\n";
  keyFile.close();


  if (state == Encode)
    {
      std::stringstream textFileName;
      textFileName << "pt_" << testInfo.count();
      
      std::fstream textFile;
      textFile.open(textFileName.str().c_str(), std::ios_base::out);  
      if (!textFile.is_open())
	{
	  std::cerr << "Couldn't open " << textFileName.str() << "\n";
	  return false;
	}


      /**********************************
       * 
       *   Apparently in just this one case the algorithm fails to
       * process text with lowercase hex digits. We'll take that as
       * a precondition rather than a bug since it's not relevant to
       * the actual encryption algorithm.
       *
       *******/
      
      textFile << boost::to_upper_copy<std::string>(testInfo.plainText())
	       << "\n";
      textFile.close();
      
      spawnTest(keyFileName.str(), textFileName.str(), testInfo, Encode);
      
      std::stringstream encFileName;
      encFileName << textFileName.str() << ".enc";
      
      std::fstream encFile;
      encFile.open(encFileName.str().c_str());
      if (!encFile.is_open())
	{
	  std::cerr << "Couldn't open " << encFileName.str() << "\n";
	  perror(NULL);
	  return false;
	}
      
      std::string encrypted;
      getline(encFile, encrypted);
      encFile.close();
      
      failed = (!boost::iequals(encrypted,testInfo.cipherText()));
      if (failed)
	{
	  std::cerr << "[" << encrypted << "," << testInfo.cipherText()
		    << "]\n";
	}
      return true;
    }
  else // decode
    {
      std::stringstream cryptFileName;
      cryptFileName << "ct_" << testInfo.count();
      
      std::fstream cryptFile;
      cryptFile.open(cryptFileName.str().c_str(), std::ios_base::out);  
      if (!cryptFile.is_open())
	{
	  std::cerr << "Couldn't open " << cryptFileName.str() << "\n";
	  return false;
	}
      
      cryptFile << testInfo.cipherText() << "\n";
      cryptFile.close();
      
      spawnTest(keyFileName.str(), cryptFileName.str(), testInfo, Decode);
      
      std::stringstream decFileName;
      decFileName << cryptFileName.str() << ".dec";
      
      std::fstream decFile;
      decFile.open(decFileName.str().c_str());
      if (!decFile.is_open())
	{
	  std::cerr << "Couldn't open " << decFileName.str() << "\n";
	  perror(NULL);
	  return false;
	}
      
      std::string decrypted;
      getline(decFile, decrypted);
      decFile.close();
      
      failed = (!boost::iequals(decrypted,testInfo.plainText()));
      if (failed)
	{
	  std::cerr << "[" << decrypted << "," << testInfo.plainText()
		    << "]\n";
	}
      return true;
    }      
}

#endif
