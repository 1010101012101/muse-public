#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <string>
#include <set>
#include <vector>
#include <iostream>


#include <boost/algorithm/string.hpp>

#include "TestHarness.h"
#include "RishiDewan33.h"

const std::string trimLeadingSpaces(const std::string & line)
{
  std::string result;
  unsigned i = 0;
  while (i < line.length() && isspace(line[i]))
    i++;

  return line.substr(i);
}

void scrapeTestLine(const std::string & line, TestInfo & testInfo,
		    TestState & state)
{

  /******************************************
   *
   *  This function is meant to interpret any line that starts
   * with something other than '#'. Since plaintext or
   * ciphertext can occupy multiple lines, the third argument
   * of scrapeTestLine is used to remember the current state,
   * which can be InPlaintext, InCipherText, or InBody, which
   * means we're not in plaintext, ciphertext or a preamble.
   *    The original design was based on the idea each line 
   * in a test file contained a complete piece of information, 
   * which unfortunately isn't true because plaintext and 
   * ciphertext is split up into blocks and can occupy multiple 
   * lines, e.g., the meaning of the data on a line can be given 
   * by a tag on a previous line. Because of that, we should 
   * probably tokenize the input instead of scanning it line
   * by line, that is, break it up into units where each tag is
   * associated with the data it refers to.
   *
   ******/
  
  size_t start;

  if (line.substr(0, 8) == "COUNT = ")
    {
      testInfo.setCount(atol(line.substr(8).c_str()));
      state = InBody;
    }
  
  if (line.substr(0, 13) == "CIPHERTEXT = ")
    {
      testInfo.setCiphertext(line.substr(13));
      state = InCiphertext;
    }

  if (line.substr(0, 5) == "IV = ")
    {
      testInfo.setIV(line.substr(5));
      state = InBody;
    }

  if (line.substr(0, 6) == "KEY = ")
    {
      testInfo.setKey(line.substr(6));
      state = InBody;
    }

  if (line.substr(0, 12) == "PLAINTEXT = ")
    {
      testInfo.setPlaintext(line.substr(12));
      state = InPlaintext;
    }

  if (isspace(line[0]))
    {
      if (state == InPlaintext)
	testInfo.addPlaintext(trimLeadingSpaces(line));
      if (state == InCiphertext)
	testInfo.addCiphertext(trimLeadingSpaces(line));
    }
}

bool scrapePreambleLine(const std::string & line, TestInfo & testInfo,
			TestState & state)
{
  if (line == "[DECRYPT]")
    {
      testInfo.setTask(Decode);
      state = InBody;
      return true;
    }

  if (line == "[ENCRYPT]")
    {
      testInfo.setTask(Encode);
      state = InBody;
      return true;
    }


  if (line[0] != '#')
    return false;

  size_t start;
  
  if ((start = line.find("Key Length")) != std::string::npos)
    {
      if (line.size() < start+13)
	return false;
      
      unsigned keySize = atoi(&(line.c_str())[start+13]);
      if (keySize == 128)
	{
	  testInfo.setKeySize(Key_128);
	}
      else if (keySize == 256)
	{
	  testInfo.setKeySize(Key_256);
	}
    }

  if ((start = line.find("AESVS")) != std::string::npos)
    {
      if (line.find("VarTxt", start) != std::string::npos)
	{
	  testInfo.setTestType(VarTxt);
	}
      if (line.find("VarKey", start) != std::string::npos)
	{
	  testInfo.setTestType(VarKey);
	}
      if (line.find("MCT", start) != std::string::npos)
	{
	  testInfo.setTestType(MonteCarlo);
	}
      if (line.find("CBC", start) != std::string::npos)
	{
	  testInfo.setMode(CBC);
	}
      if (line.find("ECB", start) != std::string::npos)
	{
	  testInfo.setMode(ECB);
	}
    }

  return true;
}

bool doEncode(const TestInfo & testInfo, AESWrapper * wrapper,
	      std::string & result)
{
  if (testInfo.testType() != MonteCarlo)
    return wrapper->encode(testInfo, result);
  else
    {
      TestInfo scratch = testInfo;
      std::string intermediate;
      for (unsigned i = 0; i < 10001; i++)
	{
	  if (!wrapper->encode(scratch, intermediate))
	    return false;
	  
	  if (i < 5 || i > 9995)
	    std::cout << intermediate << "\n";
	  
	  scratch.setPlaintext(intermediate);
	}

      result = intermediate;
    }

  return true;
}

bool compareStringVector(const std::vector<std::string> & first,
			 const std::vector<std::string> & second)
{
  if (first.size() != second.size())
    return false;

  for (unsigned i = 0; i < first.size(); i++)
    if (!boost::iequals(first[i], second[i]))
      return false;

  return true;
}

void printStringVector(const std::vector<std::string> & v)
{
  for (unsigned i = 0; i < v.size(); i++)
    std::cout << v[i] << "\n";
}

bool testEncode(const TestInfo & testInfo, AESWrapper * wrapper)
{
  std::string result;
  if (doEncode(testInfo, wrapper, result))
    {
      if (boost::to_upper_copy<std::string>(result) !=
	  boost::to_upper_copy<std::string>(testInfo.cipherText()))
	{
	  std::cout << "Test " << testInfo.count() << " "
		    << "failed\n";

	  std::cout << result << "\n";
	  std::cout << testInfo.cipherText() << "\n";
	}
      else
	{
	  std::cout << "Test " << testInfo.count() << " "
		    << "passed\n";
	}
    }
  else
    {
      std::cout << "Execution error for test "
		<< testInfo.count() <<"\n";
    }

  return true;
}

bool testDecode(const TestInfo & testInfo, AESWrapper * wrapper)
{
  std::string result;
  if (wrapper->decode(testInfo, result))
    {
      if (boost::to_upper_copy<std::string>(result) !=
	  boost::to_upper_copy<std::string>(testInfo.plainText()))
	{
	  std::cout << "Test " << testInfo.count() << " "
		    << "failed\n";

	  std::cout << result << "\n";
	  std::cout << testInfo.plainText() << "\n";
	}
      else
	{
	  std::cout << "Test " << testInfo.count() << " "
		    << "passed\n";
	}
    }
  else
    {
      std::cout << "Execution error for test "
		<< testInfo.count() <<"\n";
    }
  return true;
}

void runTests(AESWrapper * wrapper)
{
  TestInfo testInfo;
  TestState state = None;
  
  char buffer[1024];
  while (fgets(buffer, 1023, stdin))
    {
      if (strlen(buffer) > 0)
	{
	  for (char *end = &buffer[strlen(buffer)-1];
	       end >= buffer && strchr(" \n\r", *end);
	       end--)
	    {
	      *end = 0;
	    }
	}
      if (buffer[0] == '#' && state != Preamble)
	{
	  state = Preamble;
	  testInfo.clear();

	  // fall through to next condition
	}
      if (state == Preamble)
	{
	  if (scrapePreambleLine(buffer, testInfo, state))
	    continue;
	  
	  // don't fall through to next condition
	}
      else if (state != None)
	{
	  if (strlen(buffer) == 0)
	    {
	      bool failed = false;

	      Task task = testInfo.task();
	      
	      if (task == Encode)
		{
		  testEncode(testInfo, wrapper);
		}
	      else
		{
		  testDecode(testInfo, wrapper);
		}
	      testInfo.clear();
	    }
	  else
	    {
	      scrapeTestLine(buffer, testInfo, state);
	    }
	}
    }
}

int main(int argc, char **argv)
{
  RishiDewan33 rd;
  runTests(&rd);
}
