#include "AESWrapper.h"


class RishiDewan33: public AESWrapper
{
  
 public:

  RishiDewan33()
    {}

  /*
  virtual bool doTestMaybe(const TestInfo & testInfo,
			   TestState state,
			   bool & failed);
  */
  
  virtual bool 
    encode(const TestInfo & testInfo,
	   std::string & result);

  virtual bool 
    decode(const TestInfo & testInfo,
	   std::string & result);

  static void
    spawnTest(const std::string & keyFile, const std::string & textFile,
	      const TestInfo & testInfo, Task state);


 private:

  bool
    encdec(const TestInfo & testInfo,
	   std::string & result, Task state);

};
