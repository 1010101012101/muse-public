#pragma once

#include <vector>
#include <set>

enum AESmode { CBC, ECB };
enum KeySize { Key_128, Key_256 };
enum TestType { VarTxt, VarKey, MonteCarlo };

enum TestState {None, Preamble, InBody, InCiphertext, InPlaintext};
enum Task {Encode, Decode};

struct TestInfo
{
  enum TestItems{have_Count, have_Key, have_IV, have_PlainText,
		 have_CipherText, have_TestType, have_AESmode,
		 have_KeySize, have_Task };

  typedef std::set<TestItems> Manifest;
  
  void clear()
  {
    m_manifest.clear();
    m_plaintext.clear();
    m_ciphertext.clear();
  }

  void setCount(unsigned count)
  {
    m_count = count;
    m_manifest.insert(have_Count);
  }

  void setKey(const std::string & key)
  {
    m_key = key;
    m_manifest.insert(have_Key);
  }

  void setIV(const std::string & IV)
  {
    m_IV = IV;
    m_manifest.insert(have_IV);
  }

  void setTask(Task t)
  {
    m_task = t;
    m_manifest.insert(have_Task);
  }
  
  void setPlaintext(const std::string & pt)
  {
    m_plaintext = pt;
    m_manifest.insert(have_PlainText);
  }

  void addPlaintext(const std::string & pt)
  {
    m_plaintext += pt;
    m_manifest.insert(have_PlainText);
  }
  
  void setCiphertext(const std::string & ct)
  {
    m_ciphertext = ct;
    m_manifest.insert(have_CipherText);
  }

  void addCiphertext(const std::string & ct)
  {
    m_ciphertext += ct;
    m_manifest.insert(have_CipherText);
  }

  void setKeySize(KeySize s)
  {
    m_keySize = s;
    m_manifest.insert(have_KeySize);
  }

  void setMode(AESmode m)
  {
    m_mode = m;
    m_manifest.insert(have_AESmode);
  }

  void setTestType(TestType t)
  {
    m_testType = t;
    m_manifest.insert(have_TestType);
  }

  bool haveCount() const
  {
    return (m_manifest.find(have_Count) != m_manifest.end());
  }

  unsigned count() const
  {
    return m_count;
  }

  bool haveCipherText() const
  {
    return (m_manifest.find(have_CipherText) != m_manifest.end());
  }

  const std::string & cipherText() const
  {
    return m_ciphertext;
  }

  bool havePlainText() const
  {
    return (m_manifest.find(have_PlainText) != m_manifest.end());
  }

  const std::string & plainText() const
  {
    return m_plaintext;
  }

  bool haveIV() const
  {
    return (m_manifest.find(have_IV) != m_manifest.end());
  }

  const std::string & IV() const
  {
    return m_IV;
  }

  bool haveKey() const
  {
    return (m_manifest.find(have_Key) != m_manifest.end());
  }

  const std::string & key() const
  {
    return m_key;
  }

  bool haveMode() const
  {
    return (m_manifest.find(have_AESmode) != m_manifest.end());
  }

  AESmode mode() const
  {
    return m_mode;
  }
  
  Task task() const
  {
    return m_task;
  }
  
  bool haveKeySize() const
  {
    return (m_manifest.find(have_KeySize) != m_manifest.end());
  }

  KeySize keySize() const
  {
    return m_keySize;
  }

  bool haveTestType() const
  {
    return (m_manifest.find(have_TestType) != m_manifest.end());
  }
  
  TestType testType() const
  {
    return m_testType;
  }
  
  private:

  Manifest m_manifest;
  unsigned m_count;

  KeySize m_keySize;
  AESmode m_mode;
  TestType m_testType;
  Task    m_task;
  
  std::string m_key;
  std::string m_IV;
  std::string m_plaintext;
  std::string m_ciphertext;
  
};
