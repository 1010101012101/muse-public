#pragma once

#include "TestHarness.h"

/*********************************
 *
 *   A wrapper meant to provide polymorphic access to different
 * AES encryption and decryption algorithms. The first argument,
 * a TestInfo object, contains the plain text, key and ciphertext
 * as well as information about what kind of encryption is being
 * requested. It shouldn't be in a seriously inconsistent state,
 * hopefully. The second argument says whether encryption or
 * decryption is being requested.
 *
 *  If state is "Encode", doTestMaybe is responsible for encrypting
 * the data in testInfo.plainText() using testInfo.key() and checking
 * whether the result is the same as testInfor,cipherText(). If so,
 * the third argument (failed) is set to false. If encryption returns
 * a wrong result <failed> is set to true. In either case doTestMaybe
 * returns true. If something goes wrong (other than a wrong encryption
 * result) doTestMaybe should return false and the caller should ingnore
 * the value in <failed>.
 *
 *  If the state is "Decode" the functioning of doTestMaybe is the same
 * except that the string in testInfo.cipherText() is decrypted and
 * compared to testInfo.plainText().
 *
 ****/

class AESWrapper
{
 public:

  virtual bool 
    encode(const TestInfo & testInfo,
	   std::string & result) = 0;

  virtual bool 
    decode(const TestInfo & testInfo,
	   std::string & result) = 0;

  /*
  virtual bool doTestMaybe(const TestInfo & testInfo,
			   TestState state,
			   bool & failed)   = 0;
  */
};

