#include <iostream>
#include "RandomGraph.h"
#include "Digraph.h"
#include "Digraph_check_2.h"
int main(int argc, char ** argv)
{
  for (unsigned i = 0; i < 10000; i++)
    {
      RandomGraph g(atoi(argv[1])+i, atoi(argv[2]), atof(argv[3]));
      Digraph dg(g);
      Digraph_check_2 dgc(g);
      bool boost_result = dg.isConnected();
      bool my_result = dgc.isConnected();

      if (boost_result != my_result)
	{
	  std::cerr << "failed on seed " << atoi(argv[1])+i << "\n";
	  std::cerr << "boost: " << boost_result << "\n";
	  std::cerr << "me: " << my_result << "\n";
	  dg.printDot();
	  g.printDot(std::cout);
	  return 1;
	}
    }
  std::cerr << "passed\n";
  return 0;
}
