#pragma once

/*****************************************************
 *
 *  Various tests of graph properties, implemented by looking
 * at the structure of the graph rather than by traversing it.
 * The idea is to cross-check the results with the ones we
 * get from an alternate implementation that does traverse the
 * tree. 
 *
 *  For this implementation, I used boost when it provides a
 * built-in test or, in some cases, when I found example code
 * that looked well-vetted. In the other cases I added informal
 * proofs the the characteristics checked here are equivalent to
 * those given in [insert reference here].
 *
 ***/

#include <boost/graph/graph_traits.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/topological_sort.hpp>
#include <boost/graph/connected_components.hpp>
#include <boost/graph/bipartite.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/boyer_myrvold_planar_test.hpp>
#include <boost/graph/strong_components.hpp>
#include <boost/graph/graphviz.hpp>


#include "GraphClassifier.h"

using namespace boost;

class Digraph
{

public:

  typedef std::map<int, int> VertexMap;

  typedef adjacency_list<vecS, vecS, bidirectionalS, 
			 property<vertex_color_t, default_color_type>
			 > Boost_Digraph;

  typedef adjacency_list<vecS, vecS, undirectedS, 
                         property<vertex_color_t, default_color_type>
                        > Boost_Unigraph;

  typedef property_map<Boost_Digraph, vertex_index_t>::type IndexMap;
  typedef property_map<Boost_Unigraph, vertex_index_t>::type U_IndexMap;

  
  Digraph(const Graph & graph):
    m_maxVertex(0)
  {
    Graph newGraph;

    unsigned numVertices = remapEdges(graph, newGraph);

    m_graph = 
      Boost_Digraph(newGraph.edge_begin(), newGraph.edge_end(), 
		    numVertices);
    m_ugraph = 
      Boost_Unigraph(newGraph.edge_begin(), newGraph.edge_end(), 
		    numVertices);
    m_index = get(vertex_index, m_graph);
  }
    

  bool isConnected() const
  {
    std::vector<int> component(num_vertices(m_ugraph));
    int num = connected_components(m_ugraph, &component[0]);
    
    std::set<int> uniqueComponents;
    for (unsigned i = 0; i < component.size(); i++)
      uniqueComponents.insert(component[i]);

    return (uniqueComponents.size() == 1);
  }

  bool isBipartite() const
  {
    return is_bipartite(m_ugraph);
  }
    
  bool isCycleGraph() const
  {

       /****************************************
     *
     *  Does the graph consist of a single cycle? This is a directed
     * graph, so each vertex has to have exactly one successor and one
     * predecessor, and the graph is connected (when interpreted as an
     * undirected graph).
     *
     *  The official spec is that [1] all nodes can be reached from the
     * root, that [2] the edge relation is functional and that [3] any node
     * can be reached from any other node. If so, the graph must be
     * connected (from [1] or [3]), and each node has at most one successor 
     * (from [2]). By [3], each node must have at least one successor, so
     * each node has exactly one successor and hence the number of edges 
     * is the same as the number of nodes. But that means that if some node 
     * has more than one predecessor, then some other node must have
     * no predecessors, which contradicts [3].
     *
     *  Conversely, if each node has exactly one successor then [2] holds.
     * Additionally the undirected graph is a cycle graph because any graph
     * in which each vertex has two incident edges consists of disconnected
     * cycles, but the graph is connected so it must consist of just a single
     * cycle. Suppose that some node v is unreachable from some node u. Let
     * U be the set of successors of u. U can't contain a cycle in the 
     * undirected graph because it doesn't contain v, and there's already 
     * a cycle that does contain v, so there would then be two cycles. 
     * Therefore, any path created by directing the edges in U must end.
     * Let u' be the last vertex in such a path. u' can't have a successor
     * in U by the definition of u', and it can't have a successor outside
     * of U by the definition of U, so it has no successors, but that 
     * contradicts the assumption that each vertex has an outgoing edge.
     * Therefore [1] and [3] must hold as well.
     *
     *****/

    if (!isConnected()) 
      return false;


    std::map<int, int> inEdges;
    std::map<int, int> outEdges;

    graph_traits<Boost_Digraph>::edge_iterator ei, ei_end;
    for (boost::tie(ei, ei_end) = edges(m_graph); ei != ei_end; ++ei)
    {
      int sourceV = source(*ei, m_graph);
      int sinkV = target(*ei, m_graph);

      if (outEdges.find(sourceV) != outEdges.end())
	return false;

      if (inEdges.find(sinkV) != inEdges.end())
	return false;

      outEdges.insert(std::make_pair(sourceV, sinkV));
      inEdges.insert(std::make_pair(sinkV, sourceV));
    }

    return outEdges.size() == num_vertices(m_graph);
  }

  bool isUndirectedCycleGraph() const
  {
    /****************************************
     *
     *  Does the graph consist of a single cycle when viewed as
     * an undirected graph? This algorithm tries to cleverly do
     * this based on the directed graph because I'm trying to
     * get two different implementations for each of the tests.
     *   We check that each node has two adjacent edges, and then
     * check that the number of edges is equal to the number of
     * nodes. But for this to work, we have to check the number of
     * undirected edges, which might not be the same as the number
     * of directed edges because there can be two directed edges
     * between a single pair of vertices, and in the undirected
     * graph with the same topology they'd be represented by just one
     * edge.
     *
     ********/

    if (!isConnected()) 
      return false;

    if (num_vertices(m_graph) < 3)
      return false;
    
    std::map<int, int> edgeCounts;
    std::set< std::pair<int, int> > uniqueEdges;
    
    graph_traits<Boost_Digraph>::edge_iterator ei, ei_end;
    for (boost::tie(ei, ei_end) = edges(m_graph); ei != ei_end; ++ei)
    {
      int sourceV = source(*ei, m_graph);
      int sinkV = target(*ei, m_graph);

      std::pair<int,int> undirected =
	std::make_pair(std::min(sourceV, sinkV),
		       std::max(sourceV, sinkV));

      if (uniqueEdges.find(undirected) == uniqueEdges.end())
	{
	  std::map<int, int>::iterator it = edgeCounts.find(sourceV);
	  if (it != edgeCounts.end())
	    it->second++;
	  else
	    edgeCounts.insert(std::make_pair(sourceV, 1));
	  
	  it = edgeCounts.find(sinkV);
	  if (it != edgeCounts.end())
	    it->second++;
	  else
	    edgeCounts.insert(std::make_pair(sinkV, 1));
	  
	  uniqueEdges.insert(undirected);
	}
    }

    for (std::map<int, int>::iterator it = edgeCounts.begin(),
	   last = edgeCounts.end();
	 it != last; 
	 it++)
      {
	
	if (it->second != 2)
	  return false;
      }	  

    return uniqueEdges.size() == num_vertices(m_graph);
  }

  bool isAcyclic() const
  {
    /****************************************
     *
     *  Does the graph fail to contain a cycle? Adapted from
     * http://www.boost.org/doc/libs/1_56_0/libs/graph/example/file_dependencies.cpp
     *
     **************/

    bool has_cycle = false;
    cycle_detector vis(has_cycle);
    depth_first_search(m_graph, visitor(vis));
    return !has_cycle;
  }

  
  bool isSinglyLinkedList() const
  {
    /************************************************
     *
     *  Check that the graph is connected, each node has
     * at most one successor, exactly one node has no
     * successors, and one node has no predecessors.
     *
     *  The official definition says [1] the edge relation is 1:1;
     * [2] the graph is acyclic [3] all vertices can be reached from
     * the root, and [4] the edge relation is functional. 
     *
     *  [1] is the same as the requirement that each node has at
     * most one successor. Let R be the set of vertices reachable from
     * the root, and S be the set not reachable from the root. If S
     * is nonempty, there must be an edge from some member of S to
     * some member of R (say r') for the graph to be connected, but 
     * this edge can't be on a path from r to r' because no node in S 
     * is on such a path. But r' is reachable from r so it must have a
     * different incoming edge on a path from r, which contradicts [1],
     * so S must be empty and [3] holds. If the graph is connected there 
     * must be at least N-1 edges (where N is the number of vertices), and
     * if each node has at most one successor and one has none, then
     * there are at most N-1 edges, so there are exactly N-1 edges,
     * and if some node has two successors then two nodes have none,
     * which contradicts the requirement that only one node has no
     * successors, therefore [4] must hold. If the graph has a cycle consisting 
     * of nodes in some set C, and T consists of t and its predecessors, 
     * then T-C must be nonempty because each vertex in C must have a 
     * successor and t has none. Since all nodes in C have a successor in
     * C and no vertex can have two successors, no vertex in C has a successor
     * in T. But all vertices in C and all vertices in T are reachable
     * from r, so there must be some vertex reachable from r with a child
     * that reaches T and not C, and one that reaches C and not T, but
     * that vertex has two successors. T can't be empty so C must be, 
     * which shows [2].
     *
     *  Conversely, [3] implies that the graph is connected.
     * If the edge relation is 1:1 and functional, e.g.,
     * edge has a unique predecessor and a unique successor, there can
     * be at most N-1 edges, so at least one node has no predecessors 
     * and at least one has no successors. On the other hand, since
     * the graph is connected there are at least N-1 edges, and if more
     * than one node has no sucessors then some node must have more than
     * one, which contradicts [4]. Since N-1 nodes must have successors
     * and there are only N-1 edges, each node that has a successor must
     * have just one. [2] is apparently unnecessary.
     *
     ******/

    
    if (!isConnected()) 
      return false;


    std::map<int, int> edgeCounts;
    initializeEdgeCounts(edgeCounts);
    countOutEdges(edgeCounts);


    bool hasTail = false;

    for (std::map<int, int>::iterator it = edgeCounts.begin(),
	   last = edgeCounts.end();
	 it != last; 
	 it++)
      {
	if (it->second > 1)
	  return false;

	if (it->second == 0)
	{
	  if (hasTail)
	    return false;
	  else
	    hasTail = true;
	}	  
      }

    if (!hasTail)
      return false;

    std::map<int, int> inCounts;
    initializeEdgeCounts(inCounts);
    countInEdges(inCounts);

    unsigned numHeads = 0;
    
    for (std::map<int, int>::iterator it = inCounts.begin(),
	   last = inCounts.end();
	 it != last; 
	 it++)
      {
	if (it->second == 0)
	  numHeads++;
	if (numHeads > 1)
	  return false;
      }

    return numHeads == 1;
  }

  bool isTreeShaped() const
  {

    /******************************
     *
     *   E.g., could be made into a tree by redirecting edges.
     *
     ******/

    if (!isConnected()) 
      return false;


    return (num_vertices(m_graph) == num_edges(m_graph) + 1);
  }

  bool isPlanar() const
  {
    return boyer_myrvold_planarity_test(m_graph);
  }

  bool hasSingleRoot() const
  {
    /*******************************************
     *
     *  I'm saying that a graph is rooted if it has a single 
     * vertex from which all other nodes can be reached, but which
     * has no incoming edges.
     *
     *******/

    if (!isConnected()) 
      return false;

    std::map<int, int> edgeCounts;
    initializeEdgeCounts(edgeCounts);
    countInEdges(edgeCounts);

    for (std::map<int, int>::iterator it = edgeCounts.begin(),
	   last = edgeCounts.end();
	 it != last; 
	 it++)
      {
	if (it->second == 0)
	  return true;
      }

    return false;
  }

  bool isTree() const
  {
 
   /*************************************************
     *
     *  Is connected, has a root and has at most one incoming
     * edge per node.
     *
     *  The official definition is that [1] the edge relation is 1:1,
     * [2] no vertex is a predecessor of the root, and [3] all
     * vertices can be reached from the root. [2] and [3] are equivalent
     * to my definition of "having a root" (see the previous test)
     * and [1] is equivalent to the requirement that each node has
     * at most one incoming edge. 
     *
     ******/
    
    if (!isConnected()) return false;
    if (!hasSingleRoot()) return false;

    std::map<int, int> edgeCounts;
    initializeEdgeCounts(edgeCounts);
    countInEdges(edgeCounts);

    for (std::map<int, int>::iterator it = edgeCounts.begin(),
	   last = edgeCounts.end();
	 it != last; 
	 it++)
      {
	if (it->second > 1)
	  return false;
      }

    return true;
  }

  bool isDoublyLinkedTree() const
  {
    
    /*******************************************
     *
     *  The graph is connected and symmetric, and there are N-1
     * entries in the upper diagonal of the edge relation. 
     * Additionally, until I find out if boost considers the diagonal
     * to be part of the upper diagonal, we require that there are
     * no entries on the diagonal.
     *
     *  The official definition is that there exist edge subsets P and
     * C such that C is [1] 1:1, [2] if C contains (a,b) then P contains
     * (b,a) [3] there exists a vertex r with no predecessors [4] that can
     * reach all nodes via C; [5] P is functional.
     *
     *  By symmetry, and because there are no entries on the diagonal of the
     * edge relation, there are N-1 edges in the undirected graph, so there
     * must be a node with only one adjacent edge. Choose r to be one of
     * these nodes. All nodes must be reachable from r in the undirected
     * graph since it's connected, and by symmetry we can find some set
     * of N-1 directed edges that allow all nodes to be reached from r, which
     * shows [4]. Let C be such a set. Since each node except r must have at 
     * least one incoming edge in C, no node can have two (since there are only
     * N-1 edges), and this shows [1]. It also implies that C is antisymmetric
     * because if (a,b) is in C and (b,a) is as well, then one can be deleted
     * without effecting the connectedness of the undirected graph, but then
     * C would only have N-2 edges, which isn't enough for each node other
     * than r to have incoming edge. Since there are no entries on the 
     * diagonal of the edge relation and the full edge relation is symmetric, 
     * we can choose P to be N-C and conclude [2], and (with [1]) conclude [5].
     *
     ***/
    
    if (!isConnected())
      return false;

    EdgeRelation r(m_graph, m_index);
    if (!r.symmetric())
      return false;

    EdgeRelation u = r.upperDiagonal();

    return (u.size() == num_vertices(m_graph) - 1);
  }

  bool isDoublyLinkedList() const
  {
        /*******************************************************
     *
     *  Is connected, the edge relation is symmetric, the
     * the upper diagonal of the edge relation has exactly
     * N-1 entries, and there are no entries on the diagonal
     * of the edge relation. (Currently I can't find documentation
     * for the boost upperDiagonal method, or else it might be
     * possible to do away with the last requirement). Two nodes exist
     * that have one incoming and one outgoing edge each, and the
     * others have two incoming and two outgoing edges.
     *
     *   The offical definition is that [1] the forward edge relation is 
     * 1:1, [2] the back-edge relation is 1:1, [3] the forward relation is
     * acyclic, [4] (a,b) is in the forward relation iff (b,a) is in the
     * backward relation, [5] all nodes can be reached from the root via
     * the forward relation, and [6] the forward and backward relations
     * are functional. There's an implicit existential quantification
     * on the forward and backward relations.
     *
     *
     * 
     * Let r and t be the two vertices with only adjacent edges (it
     * doesn't matter which is which). Since the graph is connected, there's 
     * some set of undirected edges connecting r to t, and since the edge
     * relation is symmetric there must be some a directed set of edges
     * by which r reaches t, some set by which t reaches r. Choose the
     * former set of edges to be F and the latter to be B.  Since the total
     * number of edges is 2(N-1), and by symmetry, F and B must each contain
     * N-1 edges. Therefore, each node in the directed graph (induced by)
     * F is connected and has N-1 edges, each node has at most one
     * successor and only one node has no successor, and exactly one node
     * has no predecessor, so F is a singly linked list, which shows [1] and
     * [3] and [5], and also shows [6] for the forward relation. The
     * analogous argument for B shows [2] and it shows [6] for the backward
     * relation. [4] follows from the symmetry requirement.
     *
     *  Conversely, assume we have edge sets F and B satisfying requirements
     * [1]-[6]. By [1], [3], [5] and [6] F is a singly linked list, so
     * so all vertices have at most one predecessor and one successor
     * in F, while one has no predecessor and one has no successor,
     * furthermore there are N-1 edges in F. The edge relation is symmetric
     * by [4], and by symmetry there are N-1 edges in B, and each vertex has 
     * at most 2 incoming and 2 outgoing edges in (F U B), while two nodes 
     * have one incoming and one outgoing edge. Since there are 2(N-1) edges, 
     * by symmetry N-1 must be in the upper diagonal of the edge relation, and 
     * by [3] there are no entries on the diagonal.
     *
     */
    
    if (!isConnected())
      return false;

    EdgeRelation r(m_graph, m_index);
    if (!r.symmetric())
      return false;

    EdgeRelation u = r.upperDiagonal();

    std::map<int, int> edgeCounts;
    initializeEdgeCounts(edgeCounts);

    for (EdgeRelation::const_iterator it = u.begin(), last = u.end();
	 it != last; it++)
      {
	edgeCounts[it->source()]++;
	edgeCounts[it->sink()]++;
      }

    unsigned numEnds = 0;

    for (std::map<int, int>::iterator it = edgeCounts.begin(),
	   last = edgeCounts.end();
	 it != last; 
	 it++)
      {
	if (it->second > 2)
	{
	  return false;
	}
	else if (it->second == 1)
	{
	  if (numEnds >= 2)
	    return false;

	  numEnds++;
	}		
      }
    
    return (numEnds == 2);

  }

  bool isStronglyConnected() const
  {

    if (num_vertices(m_graph) == 0)
      return true;
    
    /*************************
     *
     *  From http://www.boost.org/doc/libs/1_42_0/libs/graph/example/strong_components.cpp
     *
     ******/

    typedef graph_traits<Boost_Digraph>::vertex_descriptor Vertex;
    std::vector<int> component(num_vertices(m_graph)), 
      discover_time(num_vertices(m_graph));
    std::vector<default_color_type> color(num_vertices(m_graph));
    std::vector<Vertex> root(num_vertices(m_graph));
    int num = strong_components(m_graph, &component[0], 
				root_map(&root[0]).
				color_map(&color[0]).
				discover_time_map(&discover_time[0]));

    return (num == 1);
  }

  void printEdges() const
  {

    std::cout << "edges(g) = ";
    graph_traits<Boost_Digraph>::edge_iterator ei, ei_end;
    for (boost::tie(ei, ei_end) = edges(m_graph); ei != ei_end; ++ei)
      std::cout << "(" << m_index[source(*ei, m_graph)] 
		<< "," << m_index[target(*ei, m_graph)] << ") ";
    std::cout << std::endl;
  }

  void printConnectedComponents() const
  {
    std::vector<int> component(num_vertices(m_graph));
    int num = connected_components(m_graph, &component[0]);
    
    std::cout << "Components: ";
    for (unsigned i = 0; i < component.size(); i++)
      std::cout << component[i] << " ";
    std::cout << '\n';
  }

  void printDot() const
  {
    boost::write_graphviz(std::cout, m_graph);
  }
  
private:

  /*********************************************
   *
   *  This is part of the cycle detection code I copied from
   * http://www.boost.org/doc/libs/1_58_0/libs/graph/doc/file_dependency_example.html.
   *
   *****/
  
  struct cycle_detector : public dfs_visitor<>
  {
    cycle_detector(bool& has_cycle) 
      : m_has_cycle(has_cycle) { }
    
    template <class Edge, class Graph>
    void back_edge(Edge, Graph&) { m_has_cycle = true; }

  protected:

    bool& m_has_cycle;

  };




  int addVertex(int originalVertex)
  {
    VertexMap::const_iterator vit = m_vertexMap.find(originalVertex);
    if (vit == m_vertexMap.end())
      {
      	m_vertexMap.insert(std::make_pair(originalVertex, m_maxVertex++));
	return m_maxVertex-1;
      }
    else
      {
	return vit->second;
      }
  }

  /********************************************
   *
   *  In the boost graph representation, you specify how many
   * vertices the graph has, and the resulting representation has
   * vertices numbered from zero to one minus whatever you said.
   * But another graph representation (like the one in graphviz)
   * might adopt whatever vertex names you provide in the adjacency
   * list, so arguably the boost representation is somehow standard.
   *
   *  Here, we remap the edge representation so that the vertices are
   * numbered from zero to one minus the number of vertices. The method
   * also returns the total number of vertices.
   *
   *****************/
  
  unsigned remapEdges(const Graph & in, Graph & out)
  {

    for (Graph::vertex_const_iterator it = in.vertex_begin(), 
	   last = in.vertex_end();
	 it != last; it++)
      {
	addVertex(*it);
      }

    for (Graph::edge_const_iterator it = in.edge_begin(), 
	   last = in.edge_end();
	 it != last; it++)
      {
	int source = addVertex(it->first);
	int sink = addVertex(it->second);
	out.addEdge(source, sink);
      }


    /*************************************
     *
     *  The topology of <out> is different from that of <in> because
     * we forgot to add the single vertices. Actually it's the fault
     * of the person who wrote the Graph class that this can happen.
     * But that doesn't matter here because of the way <out> is used.
     *
     *******/

    return m_maxVertex;
  }


  void initializeEdgeCounts(std::map<int, int> & countMap) const
  {
    typedef graph_traits<Boost_Digraph>::vertex_descriptor Vertex;
    typedef graph_traits<Boost_Digraph>::vertex_iterator vertex_iter;
    std::pair<vertex_iter, vertex_iter> vp;
    for (vp = vertices(m_graph); vp.first != vp.second; ++vp.first) {
      Vertex v = *vp.first;
      countMap.insert(std::make_pair(m_index[v], 0)); 
    }    
  }


  void countOutEdges(std::map<int, int> & edgeCounts) const
  {
    graph_traits<Boost_Digraph>::edge_iterator ei, ei_end;
    for (boost::tie(ei, ei_end) = edges(m_graph); ei != ei_end; ++ei)
    {
      int sourceV = source(*ei, m_graph);

      std::map<int, int>::iterator it = edgeCounts.find(sourceV);
      if (it != edgeCounts.end())
	it->second++;
      else
	edgeCounts.insert(std::make_pair(sourceV, 1));
    }
  }

  void countInEdges(std::map<int, int> & edgeCounts) const
  {
    graph_traits<Boost_Digraph>::edge_iterator ei, ei_end;
    for (boost::tie(ei, ei_end) = edges(m_graph); ei != ei_end; ++ei)
    {
      int sinkV = target(*ei, m_graph);

      std::map<int, int>::iterator it = edgeCounts.find(sinkV);
      if (it != edgeCounts.end())
	it->second++;
      else
	edgeCounts.insert(std::make_pair(sinkV, 1));
    }
  }

  Boost_Digraph m_graph;
  Boost_Unigraph m_ugraph;
  IndexMap m_index;
  VertexMap m_vertexMap;
  unsigned m_maxVertex;


  /******************************************************
   *
   *  Define an edge relation for the graph that we can
   * index more easily than the adjacency list. It seems like
   * the kind of thing you'd be able to in boost given that the
   * documentation is a 350-page book, but it looks like finding
   * it will take longer than writing it.
   *
   *************/


  class Edge 
  {

  public:

    Edge(int source, int sink):
      m_source(source),
      m_sink(sink)
    {}

    bool operator < (const Edge & rhs) const
    {
      if (m_source == rhs.source())
	return (m_sink < rhs.sink());

      return (m_source < rhs.source());
    }

    int source() const
    {
      return m_source;
    }

    int sink() const
    {
      return m_sink;
    }

  private:

    const int m_source;
    const int m_sink;
  };



  class EdgeRelation: public std::set<Edge>
  {

    /**********************************
     *
     *   This is just a convenience wrapper, it has no data
     * members of its own.
     *
     ******/

  public:

    EdgeRelation(const Boost_Digraph & g, const IndexMap & index)
    {
      graph_traits<Boost_Digraph>::edge_iterator ei, ei_end;
      for (boost::tie(ei, ei_end) = edges(g); ei != ei_end; ++ei)
	insert(Edge(index[source(*ei, g)], index[target(*ei, g)]));
    }


    bool operator () (int source, int sink) const
    {
      return (find(Edge(source, sink)) != end());
    }

    bool operator () (const Edge & edge) const
    {
      return (find(edge) != end());
    }

    bool symmetric() const
    {
      for (const_iterator it = begin(), last = end(); it != last; it++)
      {
	if (!(*this)(it->sink(), it->source()))
	  return false;
      }

      return true;
    }

    EdgeRelation upperDiagonal() const
    {
      EdgeRelation result;
      
      for (const_iterator it = begin(), last = end(); it != last; it++)
      {
	if (it->sink() > it->source())
	  result.insert(*it);
      }

      return result;
    }


  protected:

    EdgeRelation()
    {}

  };

};
