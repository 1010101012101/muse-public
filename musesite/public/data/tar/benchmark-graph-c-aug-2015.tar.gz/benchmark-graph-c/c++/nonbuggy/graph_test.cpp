#include <iostream>
#include "RandomGraph.h"
#include "Digraph.h"
#include "Digraph_check_2.h"

#include <boost/program_options.hpp>

typedef std::set<GraphProperty> CheckSet;
typedef std::map<GraphProperty, std::pair<int,int> > CheckStats;


namespace po = boost::program_options;
bool parseOptions(unsigned argc, char **argv,
		  CheckSet & checks,
		  float & density, unsigned & numTests, long &seed,
		  unsigned & vertices)
{
  bool failed = false;

  po::options_description desc("Allowed options");
  desc.add_options()
    ("help,h", "print this message")
    ("density,d", po::value<float>(),
     "probability of a directed edge between any two vertices")
    ("numTests,n", po::value<unsigned>(), "Number of tests")
    ("seed,s", po::value<long>(), "random number seed")
    ("vertices,v", po::value<unsigned>(),
     "expected number of vertices in the graph")
    ("Acyclic,A", "test check for directed acyclic graphs")
    ("Bipartite,B", "test check for bipartite graphs")
    ("DoublyLinkedList,D", "test check for doubly linked lists")
    ("Cycle,C", "test check for cycle graphs")
    ("Konnected,K", "test check for connect graphs")
    ("ParentTree,P", "test for tree with parent pointers")
    ("stRonglyConnected,R", "test check for strongly connected graphs")
    ("SinglyLinkedList,S", "test check for singly linked lists")
    ("Tree,T", "test check for trees")
    ("UndirectedCycle,U", "test check for undirected cycle graphs");
   
  try {
    
    po::variables_map vm;    
    po::store(po::parse_command_line(argc, argv, desc), vm);
    po::notify(vm);    
    
    if (vm.count("help")) {
      std::cout << desc << "\n";
      return 1;
    }
    
    if (vm.count("density"))
      density=vm["density"].as<float>();
    else
      density=0.2;
    
    if (vm.count("numTests"))
      numTests=vm["numTests"].as<unsigned>();
    else
      numTests=100;
    
    if (vm.count("seed"))
      seed=vm["seed"].as<long>();
    else
      seed = 1232321;
    
    if (vm.count("vertices"))
      vertices=vm["vertices"].as<unsigned>();
    else
      vertices=10;
    
    if (vm.count("Acyclic"))
      checks.insert(Acyclic);
    
    if (vm.count("Bipartite"))
      checks.insert(Bipartite);
    
    if (vm.count("Cycle"))
      checks.insert(Cyclic);

    if (vm.count("DoublyLinkedList"))
      checks.insert(DoublyLinkedList);

    if (vm.count("Konnected"))
      checks.insert(Connected);

    if (vm.count("ParentTree"))
      checks.insert(TreePP);

    if (vm.count("stRonglyConnected"))
      checks.insert(StronglyConnected);

    if (vm.count("SinglyLinkedList"))
      checks.insert(SinglyLinkedList);

    if (vm.count("Tree"))
      checks.insert(Tree);

    if (vm.count("UndirectedCycle"))
      checks.insert(UndirectedCyclic);
  }
  
  catch (const po::error &ex)
  {
    std::cout << ex.what() << '\n';
    failed = true;
  }

  if (failed)
    {
      std::cout << desc << "\n";
      return false;
    }
  
  return true;
}

bool check_failed(const char * testname,
		  bool boost_result, bool my_result, long seed,
		  const RandomGraph & graph)
{
  if (boost_result != my_result)
    {
      std::cerr << testname << " test failed on seed " << seed << "\n";
      std::cerr << "boost: " << boost_result << "\n";
      std::cerr << "me: " << my_result << "\n";
      graph.printDot(std::cout);
      return true;
    }

  return false;
}

const char * propertyName(GraphProperty prop)
{
  switch (prop)
    {
    case Acyclic:
      return "Acyclic";
    case Bipartite:
      return "Bipartite";
    case Connected:
      return "Connected";
    case Cyclic:
      return "Cyclic";
    case DoublyLinkedList:
      return "DoublyLinkedList";
    case Planar:
      return "Planar";
    case Rooted:
      return "Rooted";
    case SinglyLinkedList:
      return "SinglyLinkedList";
    case StronglyConnected:
      return "StronglyConnected";
    case Tree:
      return "Tree";
    case TreePP:
      return "TreePP";
    case TreeRP:
      return "TreeRP";
    case UndirectedCyclic:
      return "UndirectedCyclic";
    }
}

void printStats(const CheckStats & stats)
{
  for (CheckStats::const_iterator it = stats.begin(),
	 last = stats.end();
       it != last;
       it++)
    {
      std::cerr << propertyName(it->first)
		<< ": no = " << it->second.first
		<< "; yes = " << it->second.second
		<< "\n";
    }
}

void updateStats(CheckStats &stats, GraphProperty prop,
		 const RandomGraph & g, bool answer)
{
  unsigned oldCount = answer? stats[prop].second: stats[prop].first;
  unsigned newCount = g.numVertices();
  
  if (newCount > oldCount)
    {
      if (answer)
	stats[prop].second = newCount;
      else
	stats[prop].first = newCount;
    }
}

int main(int argc, char ** argv)
{
  float density = 0;
  unsigned vertices = 0;
  long seed = 0;
  unsigned numTests = 0;
  CheckSet checks;
  CheckStats stats;
  
  if (!parseOptions(argc, argv, checks, density, numTests, seed, vertices))
      return 0;
  

  for (unsigned i = 0; i < numTests; i++)
    {
      RandomGraph g(seed+i, vertices, density);
      Digraph dg(g);
      Digraph_check_2 dgc(g);

      if (checks.find(Acyclic) != checks.end())
	{
	  bool boost_result = dg.isAcyclic();
	  bool my_result = dgc.isAcyclic();
	  if (check_failed("acyclic", boost_result, my_result,
			   seed+i, g))
	    return 1;
	  
	  updateStats(stats, Acyclic, g, my_result);
	}

      if (checks.find(Bipartite) != checks.end())
	{
	  bool boost_result = dg.isBipartite();
	  bool my_result = dgc.isBipartite();
	  if (check_failed("bipartite", boost_result, my_result, seed+i, g))
	    return 1;

	  updateStats(stats, Bipartite, g, my_result);
	}


      if (checks.find(DoublyLinkedList) != checks.end())
	{
	  bool boost_result = dg.isDoublyLinkedList();
	  bool my_result = dgc.isDoublyLinkedList();
	  if (check_failed("doubly linked list", boost_result, my_result,
			   seed+i, g))
	    {
	      return 1;
	    }

	  updateStats(stats, DoublyLinkedList, g, my_result);
	}

      if (checks.find(TreePP) != checks.end())
	{
	  bool boost_result = dg.isDoublyLinkedTree();
	  bool my_result = dgc.isDoublyLinkedTree();
	  if (check_failed("tree with parent pointers", boost_result, my_result,
			   seed+i, g))
	    {
	      return 1;
	    }

	  updateStats(stats, TreePP, g, my_result);
	}

      if (checks.find(SinglyLinkedList) != checks.end())
	{
	  bool boost_result = dg.isSinglyLinkedList();
	  bool my_result = dgc.isSinglyLinkedList();
	  if (check_failed("singly linked list", boost_result, my_result,
			   seed+i, g))
	    {
	      return 1;
	    }

	  updateStats(stats, SinglyLinkedList, g, my_result);
	}

      if (checks.find(StronglyConnected) != checks.end())
	{
	  bool boost_result = dg.isStronglyConnected();
	  bool my_result = dgc.isStronglyConnected();
	  if (check_failed("strongly connected", boost_result, my_result,
			   seed+i, g))
	    {
	      return 1;
	    }

	  updateStats(stats, StronglyConnected, g, my_result);
	}

      if (checks.find(Tree) != checks.end())
	{
	  bool boost_result = dg.isTree();
	  bool my_result = dgc.isTree();
	  if (check_failed("tree", boost_result, my_result,
			   seed+i, g))
	    {
	      return 1;
	    }

	  updateStats(stats, Tree, g, my_result);
	}

      if (checks.find(UndirectedCyclic) != checks.end())
	{
	  bool boost_result = dg.isUndirectedCycleGraph();
	  bool my_result = dgc.isUndirectedCycleGraph();
	  if (check_failed("undirected cycle", boost_result, my_result,
			   seed+i, g))
	    return 1;

	  updateStats(stats, UndirectedCyclic, g, my_result);
	}

    }
  std::cerr << "passed\n";
  printStats(stats);
  return 0;
}
