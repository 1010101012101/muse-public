#pragma once

/********************************************************
 *
 *  This is an alternate implementation of our graph tests,
 * but instead of looking at graph characteristics to check
 * graph properties, these tests traverse the graph and look
 * at its structure.
 *
 ********/


#include "GraphClassifier.h"
#include "BasicEdgeRelation.h"


class Digraph_check_2
{

public:

  typedef std::pair<GraphVertex, GraphVertex> VertexPair; 
  
  
  Digraph_check_2(const Graph & graph):
    m_graph(graph)
      {}

  Digraph_check_2(const Digraph_check_2 &rhs):
    m_graph(rhs.graph())
  {}
  
  bool isConnected() const;
  bool isBipartite() const;
  bool isCycleGraph() const;
  bool isUndirectedCycleGraph() const;
  bool isAcyclic() const;
  bool isSinglyLinkedList() const;  
  bool isTree() const;
  bool isDoublyLinkedTree() const;
  bool isDoublyLinkedList() const;
  bool isStronglyConnected() const;


  /*********************************
   *
   *  isUndirectedAcyclic isn't currently part of the benchmark;
   * it could be, but we didn't put it on the list originally, and
   * I'm too lazy at the moment to write a second implementation for
   * it in Digraph.h since I'd then have to come up with a proof. It's
   * here because I needed it to check for doubly linked trees.
   *
   *******/
  
  bool isUndirectedAcyclic() const;

  Digraph_check_2 undirect() const
  {
    return Digraph_check_2(m_graph.makeUndirected());
  }

  static VertexPair orderedEdge(const VertexPair &);
  
 protected:

  BasicEdgeRelation graph() const
  {
    return m_graph;
  }
  
  /***********************************
   * 
   *  Test if the set of vertices we visited contains all vertices.
   *
   *******/
  
  bool didWeMissAny(const GraphVertexSet & visited) const;

 protected:
  
  Digraph_check_2(BasicEdgeRelation r):
    m_graph(r)
  {}
  
 private:

  BasicEdgeRelation m_graph;

};
