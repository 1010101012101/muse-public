#include <tr1/unordered_map>
#include "GraphVertex.h"

namespace std
{
  namespace tr1
  {
    template <>
    size_t
    hash<GraphVertex>::
    operator () (GraphVertex v) const
    {
      return v.number() + 1;
    }
  }
}
