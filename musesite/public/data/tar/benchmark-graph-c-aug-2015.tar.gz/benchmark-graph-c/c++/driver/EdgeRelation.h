#pragma once

/********************************************************
 *
 *  An abstract edge relation. We want more than one way of
 * representing an edge relation because then we can test
 * different implementations against each other.
 *
 *  We make this a ReferenceFacade for legibility. Otherwise, 
 * methods returning EdgeRelations would have to return
 * pointers to avoid losing their virtual methods.
 *
 ********/

#include "ReferenceFacade.h"
#include "Graph.h"
#include "GraphVertex.h"
#include "GraphVertexSet.h"
#include "GraphEdge.h"

class EdgeRelation: public Muse::ReferenceFacade
{

 public:

  // Find out if a directed edge exists in the relation
  // stating the source and sink explicitly
  
  bool operator () (const GraphVertex & source,
		    const GraphVertex & sink) const
  {
    return implementation_const()->queryEdge(source, sink);
  }


  // Find the sink of a given source
  
  const GraphVertexSet operator () (const GraphVertex & source) const
  {
    return implementation_const()->getSink(source);
  }

  
  // find out if the relation is symmetric

  bool symmetric() const
  {
    return implementation_const()->symmetric();
  }


  // Get the inverse of this relation.
  
  EdgeRelation operator - () const
  {
    return implementation_const()->invertMe();
  }

  EdgeRelation undirect() const
  {
    return implementation_const()->undirect();
  }

  void getEdges(std::set<GraphEdge> & edges) const
  {
    implementation_const()->getEdges(edges);
  }

  void getVertices(GraphVertexSet & vertices) const
  {
    return implementation_const()->getVertices(vertices);
  }
  
 protected:

  class Implementation: public Muse::RefImpl
   {
     
   public:
     
     virtual bool queryEdge(const GraphVertex & source,
			    const GraphVertex & sink) const = 0;
  

     
     // Find the sinks of a given source
  
     virtual GraphVertexSet getSink (const GraphVertex & source) const = 0;


     
     // find out if the relation is symmetric

     virtual bool symmetric() const = 0;


     
     // Get the inverse of this relation.
  
     virtual EdgeRelation invertMe() const = 0;


     // Make this into an undirected graph.

     virtual EdgeRelation undirect() const = 0;


     virtual void getEdges(std::set<GraphEdge> &) const = 0;
     virtual void getVertices(GraphVertexSet & vertices) const = 0;
   };       


  EdgeRelation(Implementation * impl):
    ReferenceFacade(impl)
  {}

  const Implementation * implementation_const() const
  {
    return dynamic_cast<const Implementation *>
      (ReferenceFacade::implementation_const());
  }
};

