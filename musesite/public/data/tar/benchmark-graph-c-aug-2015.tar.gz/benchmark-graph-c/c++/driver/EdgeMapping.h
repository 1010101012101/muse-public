#pragma once

#include <tr1/unordered_map>
#include "ReferenceFacade.h"


/*********************************************
 *
 *  This is just a simple graph description enclosed in a managed
 * pointer. The idea is to reuse the same basic set of edges in
 * different wrappers that present them in different ways, but
 * to do that we need to manage the graph description seperately
 * from the various bools we use to describe the presentation.
 *
 ******/

class EdgeMapping: public Muse::ReferenceFacade
{
  
 public:

  typedef std::tr1::unordered_map<GraphVertex, GraphVertexSet> VertexMap;


 EdgeMapping():
   ReferenceFacade(new Implementation())
  {}

  
  void addEdge(const GraphVertex & source,
	       const GraphVertex & sink)
  {
    implementation()->addEdge(source, sink);
  }

  void addVertex(const GraphVertex & v)
  {
    implementation()->addVertex(v);
  }
  
  GraphVertexSet forward(const GraphVertex & source) const
  {
    return implementation_const()->forward(source);
  }

  GraphVertexSet backward(const GraphVertex & source) const
  {
    return implementation_const()->backward(source);
  }

  GraphVertexSet vertices() const
  {
    return implementation_const()->vertices();
  }

protected:

  class Implementation: public Muse::RefImpl
  {
    
  public:

    Implementation()
    {}

    ~Implementation()
    {}

    
    void addEdge(const GraphVertex & source,
		 const GraphVertex & sink)
    {
      addMapping(m_forwardMap, source, sink);
      addMapping(m_backwardMap, sink, source);
      m_vertices.insert(source);
      m_vertices.insert(sink);
    }

    void addVertex(const GraphVertex & v)
    {
      m_vertices.insert(v);
    }
    
    GraphVertexSet forward(const GraphVertex & source) const
    {
      return map(m_forwardMap, source);
    }

    GraphVertexSet backward(const GraphVertex & sink) const
    {
      return map(m_backwardMap, sink);
    }

    const GraphVertexSet & vertices() const
    {
      return m_vertices;
    }
    
  private:

    void addMapping(VertexMap & map, GraphVertex source, GraphVertex sink)
    {
      VertexMap::iterator it = map.find(source);
      if (it == map.end())
	{
	  GraphVertexSet sinkSet;
	  sinkSet.insert(sink);
	  map.insert(std::make_pair(source, sinkSet));
	}
      else
	{
	  it->second.insert(sink);
	}
    }
    
    static const GraphVertexSet & map(const VertexMap & m,
				      const GraphVertex & v)
    {
      static const GraphVertexSet empty;
      
      VertexMap::const_iterator it = m.find(v);
      if (it == m.end())
	return empty;
      else
	return it->second;
    }

    VertexMap m_forwardMap;
    VertexMap m_backwardMap;
    GraphVertexSet m_vertices;
    
  };

  Implementation * implementation()
  {
    return dynamic_cast<Implementation *>
      (ReferenceFacade::implementation());
  }

  const Implementation * implementation_const() const
  {
    return dynamic_cast<const Implementation *>
      (ReferenceFacade::implementation_const());
  }
};
