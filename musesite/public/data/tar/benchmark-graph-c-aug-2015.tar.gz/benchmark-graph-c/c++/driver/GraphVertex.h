#pragma once

#include <tr1/unordered_map>
#include "SafeInt.h"

class GraphVertex: public Muse::SafeInt
{

 protected:

 GraphVertex(unsigned num):
  SafeInt(num)
  {}
};


class MakeGraphVertex: public GraphVertex
{
  
 public:

 MakeGraphVertex(unsigned num):
  GraphVertex(num)
  {}
};

