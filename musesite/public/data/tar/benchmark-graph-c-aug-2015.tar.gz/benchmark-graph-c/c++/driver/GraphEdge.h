#pragma once

class GraphEdge
{
 public:

 GraphEdge(GraphVertex source, GraphVertex sink):
   m_source(source),
   m_sink(sink)
  {}

  GraphEdge(const GraphEdge & rhs):
    m_source(rhs.source()),
    m_sink(rhs.sink())
  {}

  GraphVertex source() const
  {
    return m_source;
  }

  GraphVertex sink() const
  {
    return m_sink;
  }

  bool operator == (const GraphEdge & rhs) const
  {
    return (m_source == rhs.source() &&
	    m_sink == rhs.sink());
  }

  bool operator != (const GraphEdge & rhs) const
  {
    return !(*this == rhs);
  }

  bool operator < (const GraphEdge & rhs) const
  {
    if (m_source < rhs.source())
      return true;

    return m_sink < rhs.sink();
  }

  size_t hash() const
  {
    return (m_source.number() + 1) * (m_sink.number() + 1);
  }

private:

  const GraphVertex m_source;
  const GraphVertex m_sink;
};

