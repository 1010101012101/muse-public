#pragma once

#include <tr1/unordered_set>
#include "GraphVertex.h"

typedef std::tr1::unordered_set<GraphVertex> GraphVertexSet;
