#include <stack>
#include <vector>
#include "Digraph_check_2.h"

bool Digraph_check_2::
isConnected() const
{
  EdgeRelation u = m_graph.undirect();
  
  GraphVertexSet vertices;
  u.getVertices(vertices);


  /**************************
   *
   *   Boost thinks a graph with no vertices isn't connected, so
   * let's go with that same definition for convenience.
   *
   *****/
  
  if (vertices.size() == 0)
    return false;
  
  GraphVertexSet visited;

  GraphVertexSet::const_iterator it = vertices.begin();

  visited.insert(*it);

  /***********************************
   *
   *  Pick any vertex and see what we can reach in a preorder
   * traversal.
   *
   *****/
      
  std::stack<GraphVertex> worklist;
  worklist.push(*it);
  visited.insert(*it);

  while (worklist.size())
    {
      GraphVertex v = worklist.top();
      worklist.pop();
      
      GraphVertexSet sinks = u(v);

      for (GraphVertexSet::const_iterator sink_it = sinks.begin(),
	     sink_end = sinks.end();
	   sink_it != sink_end;
	   sink_it++)
	{
	  if (visited.find(*sink_it) != visited.end())
	    continue;
	  
	  visited.insert(*sink_it);
	  worklist.push(*sink_it);
	}
    }

  if (didWeMissAny(visited))
    return false;
  
  return true;
}


bool Digraph_check_2::
isBipartite() const
{
  std::tr1::unordered_map<GraphVertex, int> coloring;
  EdgeRelation u = m_graph.undirect();
  
  GraphVertexSet vertices;
  u.getVertices(vertices);

  GraphVertexSet visited;

  //  unsigned color = 0;

  /*******************************
   *
   *  The outer loop is meant to make sure we hit all connected
   * components of the graph. It should iterate only once per
   * component.
   *
   ********/
  
  for (GraphVertexSet::const_iterator it = vertices.begin(),
	 end = vertices.end();
       it != end;
       it++)
    {
      if (visited.find(*it) != visited.end())
	continue;

      visited.insert(*it);

      /***********************************
       *
       *  This is our first visit to this component, so we
       * can make the color whatever we like.
       *
       ******/


      coloring.insert(std::make_pair(*it, 0));


      /***********************************
       *
       *  set up a preorder traversal of the component.
       *
       *****/
      
      std::stack<GraphVertex> worklist;
      worklist.push(*it);

      while (worklist.size())
	{
	  GraphVertex v = worklist.top();
	  worklist.pop();
	  
	  unsigned color = coloring[v];

	  color = !color;
	  
	  GraphVertexSet sinks = u(v);

	  for (GraphVertexSet::const_iterator sink_it = sinks.begin(),
		 sink_end = sinks.end();
	       sink_it != sink_end;
	       sink_it++)
	    {
	      if (visited.find(*sink_it) != visited.end())
		continue;
	      
	      coloring.insert(std::make_pair(*sink_it, color));
	      visited.insert(*sink_it);
	      worklist.push(*sink_it);
	    }
	}
    }

  /********************************
   *
   *  Now iterate over all edges and check that their endpoints have
   * different colors.
   *
   ****/

  std::set<GraphEdge> edgeSet;
  u.getEdges(edgeSet);

  for (std::set<GraphEdge>::const_iterator eit = edgeSet.begin(),
	 elast = edgeSet.end();
       eit != elast;
       eit++)
    {
      if (coloring[eit->source()] == coloring[eit->sink()])
	return false;
    }

  return true;
}
      
  
bool
Digraph_check_2::
isCycleGraph() const
{
  GraphVertexSet vertices;
  m_graph.getVertices(vertices);


  if (vertices.size() == 0)
    return false;
  
  GraphVertexSet visited;

  GraphVertexSet::const_iterator it = vertices.begin();

  visited.insert(*it);

  /***********************************
   *
   *  Pick any vertex and see what we can reach in a preorder
   * traversal.
   *
   *****/
      
  GraphVertex v = *it;
  GraphVertex first = v;
  
  bool cycled = false;

  while (1)
    {
      visited.insert(v);
      GraphVertexSet sinks = m_graph(v);

      if (sinks.size() != 1)
	return false;

      GraphVertexSet::const_iterator sink_it = sinks.begin();

      if (visited.find(*sink_it) != visited.end())
	{
	  if (*sink_it != first)
	    return false;
	  
	  cycled = true;
	  break;
	}	  

      v = *sink_it;
    }
  
  if (didWeMissAny(visited))
    return false;
  
  return true;
}

bool Digraph_check_2::
isUndirectedCycleGraph() const
{
  EdgeRelation u = m_graph.undirect();
  GraphVertexSet vertices;
  u.getVertices(vertices);


  if (vertices.size() == 0)
    return false;
  
  GraphVertexSet visited;

  GraphVertexSet::const_iterator it = vertices.begin();

  visited.insert(*it);

  /***********************************
   *
   *  Pick any vertex and see what we can reach in a preorder
   * traversal. 
   *
   *****/
      
  GraphVertex v = *it;
  GraphVertex first = v;

  bool firstIteration = true;
  bool cycled = false;

  while (1)
    {
      visited.insert(v);
      GraphVertexSet sinks = u(v);

      if (sinks.size() != 2)
	return false;

      bool foundSuccessor = false;
      
      for (GraphVertexSet::const_iterator sink_it = sinks.begin(),
	     sink_end = sinks.end();
	   sink_it != sink_end;
	   sink_it++)
	{
	  if (visited.find(*sink_it) == visited.end())
	    {
	      v = *sink_it;
	      foundSuccessor = true;
	    }
	  else if (*sink_it == first && !firstIteration)
	    {
	      cycled = true;
	    }	  
	}

      firstIteration = false;
      if (!foundSuccessor)
	break;
    }

  if (!cycled)
    return false;
  
  if (didWeMissAny(visited))
    return false;
  
  return true;
}


bool
Digraph_check_2::
isAcyclic() const
{
  GraphVertexSet vertices;
  m_graph.getVertices(vertices);

  GraphVertexSet visited;

  /*******************************
   *
   *  The outer loop is meant to make sure we hit all connected
   * components of the graph. It should iterate only once per
   * component.
   *
   ********/
  
  for (GraphVertexSet::const_iterator it = vertices.begin(),
	 end = vertices.end();
       it != end;
       it++)
    {

      /********************************
       *
       *   Only consider nodes without incoming edges.
       *
       ******/

      if  ((-m_graph)(*it).size())
	continue;


      visited.insert(*it);

      
      /***********************************
       *
       *  set up a preorder traversal of the component.
       *
       *****/
      
      std::stack< std::vector<GraphVertex> > worklist;

      std::vector<GraphVertex> first;
      first.push_back(*it);
      worklist.push(first);
      
      while (worklist.size())
	{
	  std::vector<GraphVertex> ancestorlist = worklist.top();
	  GraphVertex v = ancestorlist.back();
	  visited.insert(v);
	  
	  worklist.pop();
	  
	  GraphVertexSet sinks = m_graph(v);

	  for (GraphVertexSet::const_iterator sink_it = sinks.begin(),
		 sink_end = sinks.end();
	       sink_it != sink_end;
	       sink_it++)
	    {
	      for (unsigned i = 0; i < ancestorlist.size(); i++)
		if (ancestorlist[i] == *sink_it)
		  return false;
	      

	      /***********************
	       * 
	       *  If we've already seen this node in a different
	       * traversal there's no need to continue traversing it
	       * since everything downstream from here has already
	       * been checked.
	       *
	       *****/
	      
	      if (visited.find(*sink_it) == visited.end())
		{
		  ancestorlist.push_back(*sink_it);
		  worklist.push(ancestorlist);
		  ancestorlist.pop_back();
		}
	    }
	}
    }

  /**********************************
   *
   *  We've now explored the descendents of every node that has no 
   * incoming edges, but if there are components where every vertex
   * is in a cycle we haven't explored those, so we need to check
   * if we've visited every node.
   *
   *****/

  return (visited.size() == vertices.size());
}

bool
Digraph_check_2::
isUndirectedAcyclic() const
{
  EdgeRelation u = m_graph.undirect();
  GraphVertexSet vertices;
  
  u.getVertices(vertices);

  GraphVertexSet visited;

  std::set<VertexPair> visitedEdges;
  
  /*******************************
   *
   *  The outer loop is meant to make sure we hit all connected
   * components of the graph. It should iterate only once per
   * component.
   *
   ********/
  
  for (GraphVertexSet::const_iterator it = vertices.begin(),
	 end = vertices.end();
       it != end;
       it++)
    {
      if (u(*it).size() != 1)
	continue;

      
      /***********************************
       *
       *  set up a preorder traversal of the component.
       *
       *****/
      
      std::stack<VertexPair> worklist;

      GraphVertex v = *it;
      
      while(1)
	{
	  visited.insert(v);
	  
	  GraphVertexSet sinks = u(v);

	  for (GraphVertexSet::const_iterator sink_it = sinks.begin(),
		 sink_end = sinks.end();
	       sink_it != sink_end;
	       sink_it++)
	    {
	      VertexPair theEdge = std::make_pair(v, *sink_it);
	      if (visitedEdges.find(orderedEdge(theEdge)) != visitedEdges.end())
		continue;

	      worklist.push(theEdge);
	    }

	  if (!worklist.size())
	    break;

	  VertexPair newEdge = worklist.top();
	  worklist.pop();

	  visitedEdges.insert(orderedEdge(newEdge));
	  v = newEdge.second;

	  if (visited.find(v) != visited.end())
	    return false;

	}
    }

  /**********************************
   *
   *  We've now explored the descendents of every node that has no 
   * incoming edges, but if there are components where every vertex
   * is in a cycle we haven't explored those, so we need to check
   * if we've visited every node.
   *
   *****/

  return (visited.size() == vertices.size());
}


bool
Digraph_check_2::
isSinglyLinkedList() const
{
  GraphVertexSet vertices;
  m_graph.getVertices(vertices);

  GraphVertexSet visited;

  GraphVertex v = MakeGraphVertex(0);
  bool found = false;
  
  for (GraphVertexSet::const_iterator it = vertices.begin(),
	 end = vertices.end();
       it != end;
       it++)
    {
      if  (!(-m_graph)(*it).size())
	{
	  v = *it;
	  found = true;
	  break;
	}
    }

  if (!found)
    return false;

  while (1)
    {
      visited.insert(v);
      GraphVertexSet sinks = m_graph(v);

      if (sinks.size() > 1)
	return false;
      
      if (sinks.size() == 0)
	break;

      GraphVertexSet::const_iterator sink_it = sinks.begin();

      if (visited.find(*sink_it) != visited.end())
	{
	    return false;
	}	  

      v = *sink_it;
    }
  
  if (didWeMissAny(visited))
    return false;
  
  return true;
}

bool
Digraph_check_2::
isTree() const
{
  GraphVertexSet vertices;
  m_graph.getVertices(vertices);

  GraphVertexSet visited;

  /***********************************
   *
   *  Find a vertex with no incoming edges.
   *
   ****/

  GraphVertex root = MakeGraphVertex(0);
  bool found = false;
  
  for (GraphVertexSet::const_iterator it = vertices.begin(),
	 end = vertices.end();
       it != end;
       it++)
    {

      /********************************
       *
       *   Only consider nodes without incoming edges.
       *
       ******/

      if  (!(-m_graph)(*it).size())
	{
	  found = true;
	  root = *it;
	  break;
	}
    }

  if (!found)
    return false;

  visited.insert(root);

  std::stack<GraphVertex> worklist;
  worklist.push(root);
  
  while (worklist.size())
    {
      GraphVertex v = worklist.top();
      worklist.pop();

      GraphVertexSet sinks = m_graph(v);

      for (GraphVertexSet::const_iterator sink_it = sinks.begin(),
	     sink_end = sinks.end();
	   sink_it != sink_end;
	   sink_it++)
	{
	  if (visited.find(*sink_it) == visited.end())
	    {
	      worklist.push(*sink_it);
	      visited.insert(*sink_it);	  
	    }
	  else
	    {
	      return false;
	    }
	}
    }

  return !didWeMissAny(visited);
}

bool
Digraph_check_2::
isDoublyLinkedTree() const
{
  /**********************************
   *
   *  We treat a tree with a single node as a special case
   * because it doesn't easily fit into the check we have
   * below.
   *
   ******/
  
  if (!m_graph.symmetric())
    return false;

  GraphVertexSet vertices;
  m_graph.getVertices(vertices);

  
  /**********************************
   *
   *  We treat a tree with a single node as a special case
   * because it doesn't easily fit into the check we have
   * below.
   *
   ******/

  if (vertices.size() == 1)
    return true;

  if (!isUndirectedAcyclic())
    return false;
  
  
  GraphVertexSet visited;

  /***********************************
   *
   *  Find any vertex with one incoming edge
   * and one outgoing edge.
   *
   ****/

  GraphVertex root = MakeGraphVertex(0);
  bool found = false;
  
  for (GraphVertexSet::const_iterator it = vertices.begin(),
	 end = vertices.end();
       it != end;
       it++)
    {
      unsigned incount = m_graph(*it).size();
      unsigned outcount = (-m_graph)(*it).size();

      if (incount == 1 && outcount == 1)
	{
	  found = true;
	  root = *it;
	  break;
	}
    }

  if (!found)
    return false;

  visited.insert(root);
  
  std::stack<GraphVertex> worklist;
  worklist.push(root);
  
  while (worklist.size())
    {
      GraphVertex v = worklist.top();
      worklist.pop();
      
      GraphVertexSet sinks = m_graph(v);

      for (GraphVertexSet::const_iterator sink_it = sinks.begin(),
	     sink_end = sinks.end();
	   sink_it != sink_end;
	   sink_it++)
	{
	  if (visited.find(*sink_it) == visited.end())
	    {
	      worklist.push(*sink_it);
	      visited.insert(*sink_it);	  
	    }
	}
    }

  return !didWeMissAny(visited);
}

bool
Digraph_check_2::
isDoublyLinkedList() const
{
  /***************************************
   *
   *  E.g., a doubly linked tree with exactly two candidates for the
   * root node. We don't care about efficiency, so we'll just count
   * the potential root nodes and then check if it's a doubly linked
   * tree.
   *
   *******/

  unsigned numFound = 0;
  
  GraphVertexSet vertices;
  m_graph.getVertices(vertices);
    for (GraphVertexSet::const_iterator it = vertices.begin(),
	 end = vertices.end();
       it != end;
       it++)
    {
      unsigned incount = m_graph(*it).size();
      unsigned outcount = (-m_graph)(*it).size();

      if (incount == 1 && outcount == 1)
	{
	  numFound++;
	}
    }

  if (numFound != 2)
    return false;
  else
    return isDoublyLinkedTree();
}

bool
Digraph_check_2::
isStronglyConnected() const
{
  /**************************************
   *
   *  This just uses Warshall's algorithm. But ideally we want to
   * run millions of tests so we won't use STL, just a POD matrix.
   * Even though our random graphs hve consecutively numbered
   * vertices, for completeness we shouldn't assume that but instead
   * remap the vertices into the 0..n range.
   *
   *********/
  
  GraphVertexSet vertices;
  m_graph.getVertices(vertices);


  std::tr1::unordered_map<GraphVertex, unsigned> remap;
  unsigned maxvertex = 0;
  
  unsigned numVertices = vertices.size();
  bool edges[numVertices][numVertices];

  for (unsigned x = 0; x < numVertices; x++)
    for (unsigned y = 0; y < numVertices; y++)
      edges[x][y] = (x==y);
  
  for (GraphVertexSet::const_iterator it = vertices.begin(),
	 last = vertices.end();
       it != last;
       it++)
    {
      if (remap.find(*it) == remap.end())
	remap.insert(std::make_pair(*it, maxvertex++));

      unsigned x = remap[*it];

      GraphVertexSet sinks = m_graph(*it);

      for (GraphVertexSet::const_iterator sink_it = sinks.begin(),
	     sink_last = sinks.end();
	   sink_it != sink_last;
	   sink_it++)
	{
	  if (remap.find(*sink_it) == remap.end())
	    remap.insert(std::make_pair(*sink_it, maxvertex++));
	  
	  unsigned y = remap[*sink_it];

	  edges[x][y] = true;
	}
    }

  for (unsigned k = 0; k < numVertices; k++)
    for (unsigned i = 0; i < numVertices; i++)
      for (unsigned j = 0; j < numVertices; j++)
	edges[i][j] = edges[i][j] || (edges[i][k] && edges[k][j]);
  

  for (unsigned x = 0; x < numVertices; x++)
    for (unsigned y = 0; y < numVertices; y++)
      if (!edges[x][y])
	return false;

  return true;
}

bool
Digraph_check_2::
didWeMissAny(const GraphVertexSet & visited) const
{
  GraphVertexSet vertices;
  m_graph.getVertices(vertices);

  /***************************
   *
   *   See if we missed any.
   *
   ********/
  
  for (GraphVertexSet::const_iterator vit = vertices.begin(),
	 vlast = vertices.end();
       vit != vlast;
       vit++)
    {
      if (visited.find(*vit) == visited.end())
	return true;
    }

  return false;
}

Digraph_check_2::VertexPair
Digraph_check_2::
orderedEdge(const VertexPair & p)
{
  GraphVertex low = std::min(p.first, p.second);
  GraphVertex high = std::max(p.first, p.second);

  return std::make_pair(low, high);
}
