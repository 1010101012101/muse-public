#include "BasicEdgeRelation.h"

BasicEdgeRelation::
BasicEdgeRelation(const Graph & graph):
  EdgeRelation(new Implementation(graph))
{}

BasicEdgeRelation::
BasicEdgeRelation(EdgeMapping mapping, bool reversed, bool undirected):
  EdgeRelation(new Implementation(mapping, reversed, undirected))
{}

BasicEdgeRelation
BasicEdgeRelation::
makeUndirected() const
{
  return implementation_const()->makeUndirected();
}

BasicEdgeRelation::
Implementation::
Implementation(const Graph & graph):
  m_reversed(false),
  m_undirected(false),
  m_mapping(getMapping(graph))
{}

EdgeMapping
BasicEdgeRelation::
Implementation::
getMapping(const Graph & graph)
{
  EdgeMapping result;
  
  for (Graph::edge_const_iterator eit = graph.edge_begin(),
	 end = graph.edge_end();
       eit != end;
       eit++)
    {
      GraphVertex source = MakeGraphVertex(eit->first);
      GraphVertex sink = MakeGraphVertex(eit->second);

      result.addEdge(source, sink);
    }

  for (Graph::Vertices::const_iterator vit = graph.vertex_begin(),
	 vend = graph.vertex_end();
       vit != vend;
       vit++)
    {
      result.addVertex(MakeGraphVertex(*vit));
    }

  return result;
}

BasicEdgeRelation::
Implementation::
Implementation(const EdgeMapping mapping, bool reversed, bool undirected):
  m_reversed(reversed),
  m_undirected(undirected),
  m_mapping(mapping)
{}

bool
BasicEdgeRelation::
Implementation::
queryEdge(const GraphVertex & source, const GraphVertex & sink) const
{
  GraphVertexSet sinks =
    (m_reversed)? m_mapping.backward(source): m_mapping.forward(source);

  return sinks.find(sink) != sinks.end();
}

GraphVertexSet
BasicEdgeRelation::
Implementation::
getSink(const GraphVertex & source) const
{
  if (m_undirected)
    { 
      GraphVertexSet back = m_mapping.backward(source);
      GraphVertexSet forward = m_mapping.forward(source);

      forward.insert(back.begin(), back.end());
      return forward;
    }

  else if (m_reversed)
    {
      return m_mapping.backward(source);
    }

  else
    {
      return m_mapping.forward(source);
    }
}

bool
BasicEdgeRelation::
Implementation::
symmetric() const
{
  const GraphVertexSet & all = m_mapping.vertices();
  for (GraphVertexSet::const_iterator vit = all.begin(),
	 vlast = all.end();
       vit != vlast;
       vit++)
    {
      const GraphVertexSet sinks = m_mapping.forward(*vit);
      for (GraphVertexSet::const_iterator sinkit = sinks.begin(),
	     slast = sinks.end();
	   sinkit != slast;
	   sinkit++)
	{
	  GraphVertexSet sources = m_mapping.forward(*sinkit);
	  if (sources.find(*vit) == sources.end())
	    {
	      return false;
	    }
	}
    }

  return true;
}


EdgeRelation
BasicEdgeRelation::
Implementation::
undirect() const
{
  return makeUndirected();
}

BasicEdgeRelation
BasicEdgeRelation::
Implementation::
makeUndirected() const
{
  return BasicEdgeRelation(m_mapping, m_reversed, true);
}

EdgeRelation
BasicEdgeRelation::
Implementation::
invertMe() const
{
  return BasicEdgeRelation(m_mapping, !m_reversed, m_undirected);
}

void
BasicEdgeRelation::
Implementation::
getEdges(std::set<GraphEdge> & edges) const
{
  const GraphVertexSet & vertices = m_mapping.vertices();
  for (GraphVertexSet::const_iterator source_it = vertices.begin(),
	 source_end = vertices.end();
       source_it != source_end;
       source_it++)
    {
      GraphVertexSet sinks =
	(m_reversed)? m_mapping.backward(*source_it):
	              m_mapping.forward(*source_it);

      for (GraphVertexSet::const_iterator sink_it = sinks.begin(),
	     sink_end = sinks.end();
	   sink_it != sink_end;
	   sink_it++)
	{
	  edges.insert(GraphEdge(*source_it, *sink_it));
	}
    }
}

void
BasicEdgeRelation::
Implementation::
getVertices(GraphVertexSet & vertices) const
{
  const GraphVertexSet & myVertices = m_mapping.vertices();
  vertices.insert(myVertices.begin(), myVertices.end());
}
