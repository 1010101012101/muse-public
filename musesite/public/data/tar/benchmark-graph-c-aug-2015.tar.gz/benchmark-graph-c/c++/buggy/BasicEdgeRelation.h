#pragma once

/***********************************
 *
 *  This is an EdgeRelation class built from scratch, so we can use
 * it as an alternative to our other version using boost.
 *
 ****************/

#include "EdgeRelation.h"
#include "EdgeMapping.h"

class BasicEdgeRelation: public EdgeRelation
{

 public:

  BasicEdgeRelation(const Graph & graph);

  BasicEdgeRelation makeUndirected() const;

protected:

  class Implementation: public EdgeRelation::Implementation
  {
    
  public:
    
    Implementation(const Graph & graph);
    Implementation(const EdgeMapping mapping, bool reversed, bool undirected);


    virtual bool queryEdge(const GraphVertex & source,
			   const GraphVertex & sink) const;
    
    virtual GraphVertexSet getSink(const GraphVertex & source) const;
    virtual bool symmetric() const;
    virtual EdgeRelation undirect() const;
    virtual EdgeRelation invertMe() const;
    virtual void getEdges(std::set<GraphEdge> &) const;
    virtual void getVertices(GraphVertexSet & vertices) const;

    BasicEdgeRelation makeUndirected() const;
    
    static EdgeMapping getMapping(const Graph & graph);

    
  protected:
    
    bool reversed() const;
    bool undirected() const;
    EdgeMapping mapping() const;

  private:
    
    /***********************
     *
     *   Pretend this relation is reversed from what it actually is.
     *
     *******/
    
    const bool m_reversed;
    
    
    /**********************
     *
     *  Pretend this is an undirected graph.
     *
     ****/
    
    const bool m_undirected;
    
    EdgeMapping m_mapping;
    GraphVertexSet m_vertices;
  };

  BasicEdgeRelation(const EdgeMapping mapping, bool reversed, bool undirected);

  const BasicEdgeRelation::Implementation *
  implementation_const() const
  {
    return dynamic_cast<const Implementation *>
      (ReferenceFacade::implementation_const());
  }
};
