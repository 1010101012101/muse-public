#pragma once
#include <map>


/*********************************************************
 *
 *  This file defines an interface for a function that classifies
 * graph properties.
 *
 *  This version of the graph interface uses the least amount of
 * typing that I could devise without needing extra documentation
 * to describe how the interface is supposed to work, and without
 * flagrantly embedding C code in C++.
 *   The advantage of using weak typing is that it may place fewer 
 * restrictions on what kinds of repository software can be used during 
 * synthesis, but on the other hand it may require more work since the 
 * synthesis system potentially has to create new glue code.
 *
 ****/

#include "Graph.h"

enum GraphProperty
  {
    Acyclic,
    Bipartite,
    Connected,
    Cyclic,             // Consists of a single cycle
    DoublyLinkedList,
    Planar,
    Rooted,
    SinglyLinkedList,
    StronglyConnected,
    Tree,
    TreePP,             // Tree with parent pointers
    TreeRP,              // Tree with root pointers
    UndirectedCyclic
  };



enum Answer
  {
    True,                // The graph has a given property


    False,               // The graph doesn't have the given property


    DontKnow,            // The requested test is implemented but we still 
                         // can't tell. Maybe something threw an exception.

                       
    NotImplemented       // The requested check isn't implememted.
  };


class GraphClassifier{

 public:

  virtual Answer ClassifyGraph (GraphProperty, const Graph &) = 0;

};
