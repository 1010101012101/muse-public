#include "Graph.h"

#include <boost/random/variate_generator.hpp>
#include <boost/random.hpp>
#include <boost/random/uniform_real_distribution.hpp>
#include <boost/random/geometric_distribution.hpp>


typedef boost::random::uniform_real_distribution <> uniform;
typedef boost::random::geometric_distribution <> geometric;

class RandomGraph: public Graph
{
 public:

  RandomGraph(unsigned seed, unsigned meanVertices, float density)
    {
      boost::mt19937 m_rng(seed);
      
      boost::variate_generator <boost::random::mt19937 &, geometric>
	sizegen(m_rng, geometric(1.0/(float)meanVertices));
      boost::variate_generator <boost::random::mt19937 &, uniform>
	edgeprob(m_rng, uniform(0, 1));

      unsigned numVertices = sizegen();

      for (unsigned i = 0; i < numVertices; i++)
	addVertex(i);

      for (unsigned i = 0; i < numVertices; i++)
	for (unsigned j = 0; j < numVertices; j++)
	  if (i!=j && edgeprob() < density)
	    addEdge(i,j);
    }

  void printDot(std::ostream & str) const
  {
    str << "digraph random{\n";

    for (vertex_const_iterator it = vertex_begin(),
	   last = vertex_end();
	 it != last;
	 it++)
      {
	str << '\t' << *it << "\n";
      }

    for (edge_const_iterator it = edge_begin(),
	   last = edge_end();
	 it != last;
	 it++)
      {
	str << '\t' << it->first << " -> " << it->second << "\n";
      }

    str << "}\n";
  }
};

	       
