#pragma once

/*********************************************************
 *
 *  This is our input graph representation. It's sort of inspired by
 * graphviz in that you can specify vertices either by explicitly
 * stating that they exist (addVertex()) or mentioning them in an
 * edge (addEdge()). However, vertices have to be integers.
 * The class doesn't guarantee that the vertices mentioned
 * in its internal representation of the edge set are also listed in
 * the vertex set.
 *
 ***********************************************************/

#include <map>
#include <set>

class Graph
{
 public:

  typedef std::multimap<int, int> Edges;
  typedef std::set<int> Vertices;

  typedef Edges::const_iterator edge_const_iterator;
  typedef Vertices::const_iterator vertex_const_iterator;

  edge_const_iterator edge_begin() const
  {
    return m_edges.begin();
  }

  edge_const_iterator edge_end() const
  {
    return m_edges.end();
  }

  vertex_const_iterator vertex_begin() const
  {
    return m_vertices.begin();
  }

  vertex_const_iterator vertex_end() const
  {
    return m_vertices.end();
  }

  void addEdge(int source, int sink)
  {
    m_edges.insert(std::make_pair(source, sink));
  }

  void addVertex(int vertex)
  {
    m_vertices.insert(vertex);
  }

  unsigned numVertices() const
  {
    return m_vertices.size();
  }
  
 private:

  Vertices m_vertices;
  Edges m_edges;
};

