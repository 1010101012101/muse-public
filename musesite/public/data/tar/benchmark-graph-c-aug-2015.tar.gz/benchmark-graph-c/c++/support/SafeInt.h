#pragma once

#include <stddef.h>

/*******************************
 *
 *  An way to distinguish between different integral types that are
 * used as indices. The idea is that to create such a type we inherit
 * from SafeInt, protect the constructor that we use to build a new
 * object from an unsigned. Then we inherit off of that type to create
 * a type that we use to create an object of the first type. This avoids
 * implicit casts from integers to the newly created type. 
 *
 */

namespace Muse
{
  class SafeInt
  {

  public:

    SafeInt():
      m_number(0)
    {}

    SafeInt(const SafeInt & rhs):
      m_number(rhs.m_number)
    {}

    const SafeInt &
    operator = (const SafeInt & rhs)
    {
      m_number = rhs.m_number;
      return *this;
    }

    bool operator == (const SafeInt & rhs) const
    {
      return m_number == rhs.number();
    }

    bool operator != (const SafeInt & rhs) const
    {
      return m_number != rhs.number();
    }

    bool operator < (const SafeInt & rhs) const
    {
      return m_number < rhs.number();
    }

    unsigned number() const
    {
      return m_number;
    }

    size_t hash() const
    {
      return m_number;
    }

  protected:

    SafeInt(unsigned n):
      m_number(n)
    {}

  private:

    unsigned m_number;

  };
}

