import java.util.LinkedList;
import java.util.List;
import java.util.Random;


public class Tester {

	public static void main(String[] args) {
		
		Random rng = new Random();

		System.out.print("Array Sort Test\n*******************\n\nBefore sort:\nInt array values = ");

		Integer[] intArray = new Integer[5];
		for (int i = 0; i < intArray.length; i++){
			intArray[i] = new Integer(rng.nextInt(1000));
			System.out.print(intArray[i].toString()+" ");
		}

		System.out.print("\nAfter sort:\nInt array values = ");
		intArray = ShellSort.sortArray(intArray);
		for (int i = 0; i < intArray.length; i++){
			System.out.print(intArray[i].toString()+" ");
		}
		
		System.out.print("\n\nList Sort Test\n*******************\n\nBefore sort:\nList values = ");
		
		List<Integer> list = new LinkedList<Integer>();
		for (int i = 0; i < 5; i++){
			Integer x = new Integer(rng.nextInt(1000));
			list.add(x);
			System.out.print(x.toString()+" ");
		}
		
		list = ShellSort.sortList(list);
		
		System.out.print("\nAfter sort:\nList values = ");
		for (int i = 0; i < list.size(); i++){
			System.out.print(list.get(i).toString()+" ");
		}
		
		System.out.print("\n\nArray Sort Test with size of 2\n*******************\n\nBefore sort:\nInt array values = ");
		
		Integer[] intArray2 = new Integer[2];
		for (int i = 0; i < intArray2.length; i++){
			intArray2[i] = new Integer(rng.nextInt(1000));
			System.out.print(intArray2[i].toString()+" ");
		}

		System.out.print("\nAfter sort:\nInt array values = ");
		intArray2 = ShellSort.sortArray(intArray2);
		for (int i = 0; i < intArray2.length; i++){
			System.out.print(intArray2[i].toString()+" ");
		}
		
	}

}
