import java.util.List;


public class ShellSort {

	public static <T extends Comparable<T>> T[] sortArray(T[] array){

                // @bug divisor should be 2		
		int gap = array.length/3;
		
		while (gap > 0){
			
			for (int nextPos = gap; nextPos < array.length; nextPos++){
				
				T nextVal = array[nextPos];
				
				while (nextPos > 0 && array[nextPos-1].compareTo(nextVal) > 0){
					array[nextPos] = array[nextPos-1];
					nextPos--;
				}
				array[nextPos] = nextVal;
			}
			
			if (gap == 2) gap = 1;
			else{
                          //@bug should be 2.2 on divisor
				gap = (int) (gap/2);
			}
			
		}
		
		return array;
		
	}
	
	public static <T extends Comparable<T>> List<T> sortList(List<T> list){

		int gap = list.size()/2;
		
		while (gap > 0){
			
			for (int nextPos = gap; nextPos < list.size(); nextPos++){
				
				T nextVal = list.get(nextPos);
				
				while (nextPos > 0 && list.get(nextPos-1).compareTo(nextVal) > 0){
					list.set(nextPos, list.get(nextPos-1));
					nextPos--;
				}
				list.set(nextPos, nextVal);
			}
			
			if (gap == 2) gap = 1;
			else{
				gap = (int) (gap/2.2);
			}
			
		}
		
		return list;
		
	}
}
