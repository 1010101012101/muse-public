#!/bin/bash


java -cp /home/muse/benchmark_problems/benchmark-sort-java/generic/correct/ Tester 
