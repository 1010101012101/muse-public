#!/bin/bash


java -cp /home/muse/benchmark_problems/benchmark-sort-java/non-generic/correct  QuickSort
