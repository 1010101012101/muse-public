/******************************************************
 *
 *  Generate a list of random strings. 
 *
 ****/


#include <boost/random/variate_generator.hpp>
#include <boost/random.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <boost/random/geometric_distribution.hpp>

int main(int argc, char **argv)
{
  typedef boost::random::uniform_int_distribution <> uniform;
  typedef boost::random::geometric_distribution <> geometric;

  boost::mt19937 m_rng(atoi(argv[1]));

  boost::variate_generator <boost::random::mt19937 &, geometric>
    lengen(m_rng, geometric(0.01));

  boost::variate_generator <boost::random::mt19937 &, uniform>
    chargen(m_rng, uniform('A', 'z'));

  unsigned numElements = lengen();
  for (unsigned i = 0; i < numElements; i++)
    {
      unsigned slen = lengen();
      for (unsigned j = 0; j < slen; j++)
	std::cout << (char)(chargen());
      std::cout << "\n";
    }
}

  
