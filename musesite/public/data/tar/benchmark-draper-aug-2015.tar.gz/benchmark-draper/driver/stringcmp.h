#pragma once

#include <string>

class stringcmp
{
 public:

  stringcmp()
  {}

  stringcmp(const char *buff):
    m_string(buff)
  {}

  stringcmp(const std::string & str):
    m_string(str)
    {}

  stringcmp(const stringcmp & str):
    m_string(str.str())
  {}

  const stringcmp & operator = (const stringcmp & rhs)
  {
    if (&rhs != this)
      m_string = rhs.str();

    return *this;
  }
  
  bool operator < (const stringcmp & rhs) const
  {
    return (m_string.compare(rhs.str()) < 0);
  }

  bool operator == (const stringcmp & rhs) const
  {
    return (m_string.compare(rhs.str()) == 0);
  }

  const std::string & str() const
  {
    return m_string;
  }
  
private:

  std::string m_string;
};
  
