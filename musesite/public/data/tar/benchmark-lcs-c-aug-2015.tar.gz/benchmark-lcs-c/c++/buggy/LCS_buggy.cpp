#include <boost/random/variate_generator.hpp>
#include <boost/random.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <boost/random/geometric_distribution.hpp>

#include "LCS.h"
#include "driver.h"



/*****************
 *
 *  from http://en.wikibooks.org/wiki/Algorithm_Implementation/Strings/Longest_common_substring
 *
 ***/

#include <string>
#include <vector>
#include <iostream>

#include "LCS.h"
using std::string;


class MyLCS: public ComputeLCS
{

 public:

  void LCS(const std::vector<int> & str1,
	   const std::vector<int> & str2,
	   std::vector<int> & result)
  {
    
    if(str1.empty() || str2.empty())
      {
	return;
      }
    
    typedef std::vector<std::basic_string<int> > strvec; 
    strvec * curr = new strvec(str2.size());
    strvec * prev = new strvec(str2.size());
    strvec * swap = NULL;
    std::basic_string<int> maxSubstr;
    
    for(int i = 0; i<str1.size(); ++i)
      {
	for(int j = 0; j<str2.size(); ++j)
	  {
	    if(str1[i] != str2[j])
	      {
		(*curr)[j].clear();
	      }
	    else
	      {
		if(i == 0 || j == 0)
		  {
		    (*curr)[j].clear();
		    (*curr)[j] += str1[i];
		  }
		else
		  {
		    /*  @bug: should be (*curr)[j] = (*prev)[j-1] + str1[i];
			@bug
		    */
		    
		    (*curr)[j] = (*prev)[j] + str1[i];
		  }

		if(maxSubstr.length() < (*curr)[j].length())
		  {
		    maxSubstr = (*curr)[j];
		  }
	      }
	  }
	swap=curr;
	curr=prev;
	prev=swap;
      }
    delete curr;
    delete prev;
    for (unsigned i = 0; i < maxSubstr.size(); i++)
      result.push_back(maxSubstr[i]);
  }
};


int main(int argc, char **argv)
{
  MyLCS lcs;
  if (!driver(1293829, 10000, &lcs))
    printf("failed\n");
  else
    printf("passed\n");
}
