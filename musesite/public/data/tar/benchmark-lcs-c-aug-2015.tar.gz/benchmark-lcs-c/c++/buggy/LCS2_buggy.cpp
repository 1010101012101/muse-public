#include <boost/random/variate_generator.hpp>
#include <boost/random.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <boost/random/geometric_distribution.hpp>


#include "LCS.h"
#include "driver.h"

// adapted from http://www.geeksforgeeks.org/longest-common-substring/

/* Dynamic Programming implementation of LCS problem */
#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;

class MyLCS: public ComputeLCS
{

 public:

  /* Returns length of longest common substring of X[0..m-1] and Y[0..n-1] */
  void LCSubStr(int *X, int *Y, int m, int n, std::vector<int> & result)
  {
    // Create a table to store lengths of longest common suffixes of
    // substrings.   Notethat LCSuff[i][j] contains length of longest
    // common suffix of X[0..i-1] and Y[0..j-1]. The first row and
    // first column entries have no logical meaning, they are used only
    // for simplicity of program


    /**************************************************************
     * 
     *  Each table entry is a std::pair where the first elemnt stores the
     * start of the substring in X, and the second element stores its
     * length. For legibility, if LCSuff[i][j] isn't part of any common
     * substring, we set its first element to -1 as well as redundantly
     * setting the second element to zero.
     *
     ****/
    
    std::pair <int,int> LCSuff[m+1][n+1];
    std::pair <int,int> max = std::make_pair(-1,0);  // To store length of the longest common substring

    /* Following steps build LCSuff[m+1][n+1] in bottom up fashion. */
    for (int i=0; i<=m; i++)
    {
        for (int j=0; j<=n; j++)
        {
            if (i == 0 || j == 0)
	      {
                LCSuff[i][j].first = -1;
                LCSuff[i][j].second = 0;
	      }	    
            else if (X[i-1] == Y[j-1])
            {
                LCSuff[i][j].second = LCSuff[i-1][j-1].second + 1;

		if (LCSuff[i-1][j-1].first == -1)
		  {
		  /* @bug: should be i-1, since <first> is supposed
		     to store the start of the longest common substring,
		     which we've just seen at X[i-1]. @bug
		  */
		  
		    LCSuff[i][j].first = i;
		  }
		else
		  {
		    LCSuff[i][j].first =  LCSuff[i-1][j-1].first;
		  }

		if (LCSuff[i][j].second > max.second)
		  max = LCSuff[i][j];
            }
            else LCSuff[i][j] = std::make_pair(-1,0);
        }
    }
    
    unsigned start = max.first;
    unsigned end = start+max.second;
    
    for (unsigned i =  start; i < end; i++)
      result.push_back(X[i]);
  }


  void LCS(const std::vector<int> & str1,
	   const std::vector<int> & str2,
	   std::vector<int> & result)
  {
    int X[str1.size()];
    int Y[str2.size()];

    for (unsigned i = 0; i < str1.size(); i++)
      X[i] = str1[i];

    for (unsigned i = 0; i < str2.size(); i++)
      Y[i] = str2[i];

    LCSubStr(X, Y, str1.size(), str2.size(), result);
  }
};


int main(int argc, char **argv)
{
  MyLCS lcs;
  if (!driver(1293829, 10000, &lcs))
    printf("failed\n");
  else
    printf("passed\n");
}
