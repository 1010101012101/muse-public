bool driver(unsigned seed, unsigned numTests, ComputeLCS * drivee);

