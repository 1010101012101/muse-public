#pragma once
#include <vector>

class ComputeLCS
{
 public:

  virtual void LCS(const std::vector<int> & first,
		   const std::vector<int> & second,
		   std::vector<int> & result) = 0;
};
