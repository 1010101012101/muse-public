#include <iostream>
#include <boost/random/variate_generator.hpp>
#include <boost/random.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <boost/random/geometric_distribution.hpp>

#include "bruteforce.h"

#include "LCS.h"

#define LENGTHPARAM 0.01
#define MINDIGIT 0
#define MAXDIGIT 3

template<class Char>
std::basic_string<Char>
toString(std::vector<int> data)
{
  std::basic_string<Char> result;
  
  for (unsigned i = 0; i < data.size(); i++)
    result += (data[i] % (8 << sizeof(Char)));

  return result;
}

	       
bool driver(unsigned seed, unsigned numTests, ComputeLCS * drivee)
{
  typedef boost::random::uniform_int_distribution <> uniform;
  typedef boost::random::geometric_distribution <> geometric;

  boost::mt19937 m_rng(seed);
  
  boost::variate_generator <boost::random::mt19937 &, geometric>
    lengen(m_rng, geometric(LENGTHPARAM));
  boost::variate_generator <boost::random::mt19937 &, uniform>
    symgen(m_rng, uniform(MINDIGIT, MAXDIGIT));

  for (unsigned i = 0; i < numTests; i++)
    {
      unsigned length1 = lengen();
      unsigned length2 = lengen();
      
      std::vector<int> seq1;
      std::vector<int> seq2;
      
      for (unsigned i = 0; i < length1; i++)
	seq1.push_back(symgen());
      for (unsigned i = 0; i < length2; i++)
	seq2.push_back(symgen());
      
      std::vector<int> result;
      
      drivee->LCS(seq1, seq2, result);

      if (!testLCS(toString<int>(seq1),
		   toString<int>(seq2),
		   toString<int>(result)))
	{
	  return false;
	}
    }
  
  return true;
}
