/******************************
 *
 *  This is a brute-force LCS implementation to use for testing.
 * I couldn't think of a clever way to check the correctness of
 * a claimed longest common substring without actually checking
 * if longer ones exists, but the idea of this code is to do the
 * check in such a straightforward way that the code can be verified
 * by inspection.
 * 
 *  The challenge problem asks for -some- longest common substring, 
 * so the test is to check that the claimed substring is contained
 * on both of the two strings it's supposedly common to, and that there
 * is no other common substring that's longer. The length of the 
 * longest common substring is obtained by a brute-force search over
 * all possible pairs of starting positions for a common substring,
 * and for each pair of positions we find the longest common substring
 * starting at that pair of positions.
 *
 *****/

template<class char>
unsigned
LongestCommonPrefix(const std::basic_string<char> & first,
		    const std::basic_string<char> & second,
		    unsigned startFirst, unsigned startSecond)
{
  unsigned len = first.size()-startFirst;
  if (len > second.size()-startSecond)
    len = second.size()-startSecond;

  unsigned i = 0;
  for (; i < len; i++)
    {
      if (first[i-startFirst] == second[i-startSecond])
	result += first[i];
      else
	break;
    }

  return i;
}

template<class char>
unsigned 
LongestCommonSuffix(const std::basic_string<char> & first,
		    const std::basic_string<char> & second)
{
  unsigned result = 0;
  
  for (unsigned i = 0; i < first.size(); i++)
    {
      for (unsigned j = 0; j < first.size(); j++)
	{
	  unsigned prefix =
	    LongestCommonPrefix(first, second, i, j);
	  if (prefix > result)
	    result = prefix;
	}
    }
}

template<class char>
bool testLCS(const std::basic_string<char> & first,
	     const std::basic_string<char> & second
	     const std::basic_string<char> & claimedLCS)
{
  if (first.find(claimedLCS) == std::string::npos)
    return false;
  if (second.find(claimedLCS) == std::string::npos)
    return false;

  if (LongestCommonSuffix(first, second) > claimedLCS.length())
    return false;
}
