/******************************
 *
 *  This is a brute-force LCS implementation to use for testing.
 * I couldn't think of a clever way to check the correctness of
 * a claimed longest common substring without actually checking
 * if longer ones exists, but the idea of this code is to do the
 * check in such a straightforward way that the code can be verified
 * by inspection.
 * 
 *  The challenge problem asks for -some- longest common substring, 
 * so the test is to check that the claimed substring is contained
 * on both of the two strings it's supposedly common to, and that there
 * is no other common substring that's longer. The length of the 
 * longest common substring is obtained by a brute-force search over
 * all possible pairs of starting positions for a common substring,
 * and for each pair of positions we find the longest common substring
 * starting at that pair of positions.
 *
 *****/

template<class Char>
unsigned
LongestCommonPrefix(const std::basic_string<Char> & first,
		    const std::basic_string<Char> & second,
		    unsigned startFirst, unsigned startSecond)
{
  unsigned len = first.size()-startFirst;
  if (len > second.size()-startSecond)
    len = second.size()-startSecond;

  unsigned result = 0;
  unsigned i = 0;
  for (; i < len; i++)
    {
      if (first[i+startFirst] != second[i+startSecond])
	break;
    }

  return i;
}

template<class Char>
unsigned 
LongestCommonSuffix(const std::basic_string<Char> & first,
		    const std::basic_string<Char> & second)
{
  unsigned result = 0;
  
  for (unsigned i = 0; i < first.size(); i++)
    {
      for (unsigned j = 0; j < second.size(); j++)
	{
	  unsigned prefix =
	    LongestCommonPrefix(first, second, i, j);
	  if (prefix > result)
	    result = prefix;
	}
    }

  return result;
}

template<class Char>
void printLines(const std::basic_string<Char> & seq1,
		const std::basic_string<Char> & seq2,
		const std::basic_string<Char> & result)
{
  for (unsigned i = 0; i < seq1.size(); i++)
    std::cout << seq1[i] << ' ';
  std::cout << "\n\n";
  
  for (unsigned i = 0; i < seq2.size(); i++)
    std::cout << seq2[i] << ' ';
  std::cout << "\n\n";
  
  for (unsigned i = 0; i < result.size(); i++)
    std::cout << result[i] << ' ';
  std::cout << "\n\n";
}


template<class Char>
bool testLCS(const std::basic_string<Char> & first,
	     const std::basic_string<Char> & second,
	     const std::basic_string<Char> & claimedLCS)
{
  if (first.find(claimedLCS) == std::string::npos)
    {
      printLines(first, second, claimedLCS);
      std::cout << "Claimed LCS isn't a substring of first string\n";
      return false;
    }
  
  if (second.find(claimedLCS) == std::string::npos)
    {
      printLines(first, second, claimedLCS);
      std::cout << "Claimed LCS isn't a substring of second string\n";
      return false;
    }

  unsigned lcsSize = LongestCommonSuffix(first, second);
  if (lcsSize > claimedLCS.length())
   {
      printLines(first, second, claimedLCS);
      std::cout << "Actual LCS has length " << lcsSize << "\n";
      return false;
   }

  return true;
}
